(function(){var P$=Clazz.newPackage("java.applet"),I$=[];
var C$=Clazz.newInterface(P$, "AppletContext");
})();
//Created 2018-03-16 05:14:59

(function(){var P$=Clazz.newPackage("a2s"),I$=[];
var C$=Clazz.newInterface(P$, "A2SContainer");
})();
//Created 2018-03-18 11:47:13

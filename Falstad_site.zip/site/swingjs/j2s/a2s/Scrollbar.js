(function(){var P$=Clazz.newPackage("a2s"),I$=[[0,'a2s.A2SEvent','a2s.A2SListener']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "Scrollbar", null, 'javax.swing.JScrollBar', 'a2s.A2SContainer');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.listener=null;
},1);

C$.$fields$=[['O',['listener','a2s.A2SListener']]]

Clazz.newMeth(C$, 'c$$I',  function (direction) {
;C$.superclazz.c$$I.apply(this,[direction]);C$.$init$.apply(this);
$I$(1).addListener$javax_swing_JComponent$java_awt_Component(null, this);
}, 1);

Clazz.newMeth(C$, 'c$',  function () {
;C$.superclazz.c$.apply(this,[]);C$.$init$.apply(this);
$I$(1).addListener$javax_swing_JComponent$java_awt_Component(null, this);
}, 1);

Clazz.newMeth(C$, 'c$$I$I$I$I$I',  function (orientation, value, extent, min, max) {
;C$.superclazz.c$$I$I$I$I$I.apply(this,[orientation, value, extent, min, max]);C$.$init$.apply(this);
$I$(1).addListener$javax_swing_JComponent$java_awt_Component(null, this);
}, 1);

Clazz.newMeth(C$, 'setValue$I',  function (n) {
C$.superclazz.prototype.setValue$I.apply(this, [n]);
});

Clazz.newMeth(C$, 'getMinimum$',  function () {
return C$.superclazz.prototype.getMinimum$.apply(this, []);
});

Clazz.newMeth(C$, 'getMaximum$',  function () {
return C$.superclazz.prototype.getMaximum$.apply(this, []);
});

Clazz.newMeth(C$, 'getValue$',  function () {
return C$.superclazz.prototype.getValue$.apply(this, []);
});

Clazz.newMeth(C$, 'getA2SListener$',  function () {
if (this.listener == null ) this.listener=Clazz.new_($I$(2,1));
return this.listener;
});
})();
;Clazz.setTVer('5.0.1-v2');//Created 2024-02-12 21:09:26 Java2ScriptVisitor version 5.0.1-v2 net.sf.j2s.core.jar version 5.0.1-v2

(function(){var P$=Clazz.newPackage("a2s"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "Canvas", null, 'a2s.Panel');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['Z',['notified']]]

Clazz.newMeth(C$, 'paint$java_awt_Graphics',  function (g) {
this.update$java_awt_Graphics(g);
});

Clazz.newMeth(C$, 'update$java_awt_Graphics',  function (g) {
if (!this.notified) System.out.println$S("neither paint(g) nor update(g) is implemented for " + this);
this.notified=true;
{
this.paintComponent$java_awt_Graphics && this.paintComponent$java_awt_Graphics(g);
}
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v2');//Created 2024-02-12 21:09:26 Java2ScriptVisitor version 5.0.1-v2 net.sf.j2s.core.jar version 5.0.1-v2

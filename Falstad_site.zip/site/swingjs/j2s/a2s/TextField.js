(function(){var P$=Clazz.newPackage("a2s"),I$=[[0,'java.awt.event.TextEvent']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "TextField", null, 'javax.swing.JTextField');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$$I',  function (width) {
;C$.superclazz.c$$I.apply(this,[width]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$',  function () {
;C$.superclazz.c$.apply(this,[]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$S',  function (text) {
;C$.superclazz.c$$S.apply(this,[text]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$S$I',  function (text, width) {
;C$.superclazz.c$$S$I.apply(this,[text, width]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'addTextListener$java_awt_event_TextListener',  function (textListener) {
this.getDocument$().addDocumentListener$javax_swing_event_DocumentListener(((P$.TextField$1||
(function(){/*a*/var C$=Clazz.newClass(P$, "TextField$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'javax.swing.event.DocumentListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'insertUpdate$javax_swing_event_DocumentEvent',  function (e) {
});

Clazz.newMeth(C$, 'removeUpdate$javax_swing_event_DocumentEvent',  function (e) {
});

Clazz.newMeth(C$, 'changedUpdate$javax_swing_event_DocumentEvent',  function (e) {
this.$finals$.textListener.textValueChanged$java_awt_event_TextEvent(Clazz.new_($I$(1,1).c$$O$I,[this, 0]));
});
})()
), Clazz.new_(P$.TextField$1.$init$,[this, {textListener:textListener}])));
});
})();
;Clazz.setTVer('5.0.1-v2');//Created 2024-02-12 21:09:26 Java2ScriptVisitor version 5.0.1-v2 net.sf.j2s.core.jar version 5.0.1-v2

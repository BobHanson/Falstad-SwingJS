(function(){var P$=Clazz.newPackage("a2s"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "Dialog", null, 'javax.swing.JDialog');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$$a2s_Frame$S$Z',  function (c, title, isModal) {
;C$.superclazz.c$$java_awt_Frame$S$Z.apply(this,[c, title, isModal]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v2');//Created 2024-02-12 21:09:26 Java2ScriptVisitor version 5.0.1-v2 net.sf.j2s.core.jar version 5.0.1-v2

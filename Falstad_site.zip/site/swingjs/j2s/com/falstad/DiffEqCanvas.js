(function(){var P$=Clazz.newPackage("com.falstad"),I$=[[0,'java.awt.Dimension','com.falstad.DiffEqFrame',['com.falstad.DiffEqFrame','.Order1LhsFunc'],['com.falstad.DiffEqFrame','.Order2LhsFunc'],['com.falstad.DiffEqFrame','.FreeFallLhsFunc'],['com.falstad.DiffEqFrame','.BesselLhsFunc'],['com.falstad.DiffEqFrame','.BesselIntegerLhsFunc'],['com.falstad.DiffEqFrame','.BesselHalfIntegerLhsFunc'],['com.falstad.DiffEqFrame','.LegendreLhsFunc'],['com.falstad.DiffEqFrame','.LegendreIntegerLhsFunc'],['com.falstad.DiffEqFrame','.HermiteLhsFunc'],['com.falstad.DiffEqFrame','.JacobiLhsFunc'],['com.falstad.DiffEqFrame','.Order4LhsFunc'],['com.falstad.DiffEqFrame','.EquidimensionalOrder2LhsFunc'],['com.falstad.DiffEqFrame','.PendulumLhsFunc'],['com.falstad.DiffEqFrame','.DuffingLhsFunc'],['com.falstad.DiffEqFrame','.VanDerPolFunc'],['com.falstad.DiffEqFrame','.ImpulseRhsFunc'],['com.falstad.DiffEqFrame','.StepRhsFunc'],['com.falstad.DiffEqFrame','.SquareWaveRhsFunc'],['com.falstad.DiffEqFrame','.SineWaveRhsFunc'],['com.falstad.DiffEqFrame','.SawtoothRhsFunc'],['com.falstad.DiffEqFrame','.TriangleRhsFunc'],['com.falstad.DiffEqFrame','.LinearRhsFunc'],['com.falstad.DiffEqFrame','.ExponentialRhsFunc'],['com.falstad.DiffEqFrame','.CustomRhsFunc'],['com.falstad.DiffEqFrame','.CustomYRhsFunc'],['com.falstad.DiffEqFrame','.CustomYPRhsFunc'],'java.awt.Color','java.util.Vector',['com.falstad.DiffEqFrame','.OscillatorLhsFunc'],['com.falstad.DiffEqFrame','.ZeroRhsFunc'],'com.falstad.DiffEqLayout','com.falstad.DiffEqCanvas','a2s.Choice','a2s.Button',['com.falstad.DiffEqFrame','.ValueEditCanvas'],'java.text.NumberFormat','java.util.Random']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "DiffEqCanvas", null, 'a2s.Canvas');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['pg','com.falstad.DiffEqFrame']]]

Clazz.newMeth(C$, 'c$$com_falstad_DiffEqFrame',  function (p) {
Clazz.super_(C$, this);
this.pg=p;
}, 1);

Clazz.newMeth(C$, 'getPreferredSize$',  function () {
return Clazz.new_($I$(1,1).c$$I$I,[300, 400]);
});

Clazz.newMeth(C$, 'update$java_awt_Graphics',  function (g) {
this.pg.updateDiffEq$java_awt_Graphics(g);
});

Clazz.newMeth(C$, 'paintComponent$java_awt_Graphics',  function (g) {
C$.superclazz.prototype.paintComponent$java_awt_Graphics.apply(this, [g]);
this.pg.updateDiffEq$java_awt_Graphics(g);
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v2');//Created 2024-02-12 21:09:27 Java2ScriptVisitor version 5.0.1-v2 net.sf.j2s.core.jar version 5.0.1-v2

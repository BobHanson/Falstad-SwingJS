(function(){var P$=Clazz.newPackage("com.falstad.circuit"),I$=[[0,'com.falstad.circuit.ImportExportDialogSwingJS','com.falstad.circuit.ImportExportClipboardDialog','com.falstad.circuit.ImportExportFileDialog']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "ImportExportDialogFactory");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'Create$com_falstad_circuit_CirSim$com_falstad_circuit_ImportExportDialog_Action',  function (f, type) {
var isJS=false;
{
isJS = true;
}
if (isJS) {
return Clazz.new_($I$(1,1).c$$com_falstad_circuit_CirSim$com_falstad_circuit_ImportExportDialog_Action,[f, type]);
} else if (f.applet != null ) {
return Clazz.new_($I$(2,1).c$$com_falstad_circuit_CirSim$com_falstad_circuit_ImportExportDialog_Action,[f, type]);
} else {
return Clazz.new_($I$(3,1).c$$com_falstad_circuit_CirSim$com_falstad_circuit_ImportExportDialog_Action,[f, type]);
}}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v2');//Created 2024-02-12 21:09:31 Java2ScriptVisitor version 5.0.1-v2 net.sf.j2s.core.jar version 5.0.1-v2

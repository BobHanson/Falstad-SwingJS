(function(){var P$=Clazz.newPackage("com.falstad.circuit"),I$=[[0,'java.awt.Font','com.falstad.circuit.CircuitElm','com.falstad.circuit.EditInfo','a2s.Checkbox']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "LogicInputElm", null, 'com.falstad.circuit.SwitchElm');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.FLAG_TERNARY=1;
this.FLAG_NUMERIC=2;
},1);

C$.$fields$=[['D',['hiV','loV'],'I',['FLAG_TERNARY','FLAG_NUMERIC']]]

Clazz.newMeth(C$, 'c$$I$I',  function (xx, yy) {
;C$.superclazz.c$$I$I$Z.apply(this,[xx, yy, false]);C$.$init$.apply(this);
this.hiV=5;
this.loV=0;
}, 1);

Clazz.newMeth(C$, 'c$$I$I$I$I$I$java_util_StringTokenizer',  function (xa, ya, xb, yb, f, st) {
;C$.superclazz.c$$I$I$I$I$I$java_util_StringTokenizer.apply(this,[xa, ya, xb, yb, f, st]);C$.$init$.apply(this);
try {
this.hiV= new Double(st.nextToken$()).doubleValue$();
this.loV= new Double(st.nextToken$()).doubleValue$();
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
this.hiV=5;
this.loV=0;
} else {
throw e;
}
}
if (this.isTernary$()) this.posCount=3;
}, 1);

Clazz.newMeth(C$, 'isTernary$',  function () {
return (this.flags & 1) != 0;
});

Clazz.newMeth(C$, 'isNumeric$',  function () {
return (this.flags & (3)) != 0;
});

Clazz.newMeth(C$, 'getDumpType$',  function () {
return "L".$c();
});

Clazz.newMeth(C$, 'dump$',  function () {
return C$.superclazz.prototype.dump$.apply(this, []) + " " + new Double(this.hiV).toString() + " " + new Double(this.loV).toString() ;
});

Clazz.newMeth(C$, 'getPostCount$',  function () {
return 1;
});

Clazz.newMeth(C$, 'setPoints$',  function () {
C$.superclazz.prototype.setPoints$.apply(this, []);
this.lead1=this.interpPoint$java_awt_Point$java_awt_Point$D(this.point1, this.point2, 1 - 12 / this.dn);
});

Clazz.newMeth(C$, 'draw$java_awt_Graphics',  function (g) {
var f=Clazz.new_($I$(1,1).c$$S$I$I,["SansSerif", 1, 20]);
g.setFont$java_awt_Font(f);
g.setColor$java_awt_Color(this.needsHighlight$() ? $I$(2).selectColor : $I$(2).whiteColor);
var s=this.position == 0 ? "L" : "H";
if (this.isNumeric$()) s="" + this.position;
this.setBbox$java_awt_Point$java_awt_Point$D(this.point1, this.lead1, 0);
this.drawCenteredText$java_awt_Graphics$S$I$I$Z(g, s, this.x2, this.y2, true);
this.setVoltageColor$java_awt_Graphics$D(g, this.volts[0]);
$I$(2).drawThickLine$java_awt_Graphics$java_awt_Point$java_awt_Point(g, this.point1, this.lead1);
this.updateDotCount$();
this.drawDots$java_awt_Graphics$java_awt_Point$java_awt_Point$D(g, this.point1, this.lead1, this.curcount);
this.drawPosts$java_awt_Graphics(g);
});

Clazz.newMeth(C$, 'setCurrent$I$D',  function (vs, c) {
this.current=-c;
});

Clazz.newMeth(C$, 'stamp$',  function () {
var v=(this.position == 0) ? this.loV : this.hiV;
if (this.isTernary$()) v=this.position * 2.5;
$I$(2).sim.stampVoltageSource$I$I$I$D(0, this.nodes[0], this.voltSource, v);
});

Clazz.newMeth(C$, 'getVoltageSourceCount$',  function () {
return 1;
});

Clazz.newMeth(C$, 'getVoltageDiff$',  function () {
return this.volts[0];
});

Clazz.newMeth(C$, 'getInfo$SA',  function (arr) {
arr[0]="logic input";
arr[1]=(this.position == 0) ? "low" : "high";
if (this.isNumeric$()) arr[1]="" + this.position;
arr[1]+=" (" + $I$(2).getVoltageText$D(this.volts[0]) + ")" ;
arr[2]="I = " + $I$(2,"getCurrentText$D",[this.getCurrent$()]);
});

Clazz.newMeth(C$, 'hasGroundConnection$I',  function (n1) {
return true;
});

Clazz.newMeth(C$, 'getEditInfo$I',  function (n) {
if (n == 0) {
var ei=Clazz.new_($I$(3,1).c$$S$D$D$D,["", 0, 0, 0]);
ei.checkbox=Clazz.new_($I$(4,1).c$$S$Z,["Momentary Switch", this.momentary]);
return ei;
}if (n == 1) return Clazz.new_($I$(3,1).c$$S$D$D$D,["High Voltage", this.hiV, 10, -10]);
if (n == 2) return Clazz.new_($I$(3,1).c$$S$D$D$D,["Low Voltage", this.loV, 10, -10]);
return null;
});

Clazz.newMeth(C$, 'setEditValue$I$com_falstad_circuit_EditInfo',  function (n, ei) {
if (n == 0) this.momentary=ei.checkbox.getState$();
if (n == 1) this.hiV=ei.value;
if (n == 2) this.loV=ei.value;
});

Clazz.newMeth(C$, 'getShortcut$',  function () {
return "i".$c();
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v2');//Created 2024-02-12 21:09:31 Java2ScriptVisitor version 5.0.1-v2 net.sf.j2s.core.jar version 5.0.1-v2

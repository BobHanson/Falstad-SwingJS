(function(){var P$=Clazz.newPackage("com.falstad.circuit"),I$=[[0,['com.falstad.circuit.ChipElm','.Pin'],'com.falstad.circuit.CircuitElm']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "VCOElm", null, 'com.falstad.circuit.ChipElm');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.cResistance=1000000.0;
},1);

C$.$fields$=[['D',['cResistance','cCurrent'],'I',['cDir']]]

Clazz.newMeth(C$, 'c$$I$I',  function (xx, yy) {
;C$.superclazz.c$$I$I.apply(this,[xx, yy]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$I$I$I$I$I$java_util_StringTokenizer',  function (xa, ya, xb, yb, f, st) {
;C$.superclazz.c$$I$I$I$I$I$java_util_StringTokenizer.apply(this,[xa, ya, xb, yb, f, st]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'getChipName$',  function () {
return "VCO";
});

Clazz.newMeth(C$, 'setupPins$',  function () {
this.sizeX=2;
this.sizeY=4;
this.pins=Clazz.array($I$(1), [6]);
this.pins[0]=Clazz.new_($I$(1,1).c$$I$I$S,[this, null, 0, 2, "Vi"]);
this.pins[1]=Clazz.new_($I$(1,1).c$$I$I$S,[this, null, 3, 2, "Vo"]);
this.pins[1].output=true;
this.pins[2]=Clazz.new_($I$(1,1).c$$I$I$S,[this, null, 0, 3, "C"]);
this.pins[3]=Clazz.new_($I$(1,1).c$$I$I$S,[this, null, 1, 3, "C"]);
this.pins[4]=Clazz.new_($I$(1,1).c$$I$I$S,[this, null, 2, 3, "R1"]);
this.pins[4].output=true;
this.pins[5]=Clazz.new_($I$(1,1).c$$I$I$S,[this, null, 3, 3, "R2"]);
this.pins[5].output=true;
});

Clazz.newMeth(C$, 'nonLinear$',  function () {
return true;
});

Clazz.newMeth(C$, 'stamp$',  function () {
$I$(2).sim.stampVoltageSource$I$I$I(0, this.nodes[1], this.pins[1].voltSource);
$I$(2).sim.stampVoltageSource$I$I$I$D(this.nodes[0], this.nodes[4], this.pins[4].voltSource, 0);
$I$(2).sim.stampVoltageSource$I$I$I$D(0, this.nodes[5], this.pins[5].voltSource, 5);
$I$(2).sim.stampResistor$I$I$D(this.nodes[2], this.nodes[3], 1000000.0);
$I$(2).sim.stampNonLinear$I(this.nodes[2]);
$I$(2).sim.stampNonLinear$I(this.nodes[3]);
});

Clazz.newMeth(C$, 'doStep$',  function () {
var vc=this.volts[3] - this.volts[2];
var vo=this.volts[1];
var dir=(vo < 2.5 ) ? 1 : -1;
if (vo < 2.5  && vc > 4.5  ) {
vo=5;
dir=-1;
}if (vo > 2.5  && vc < 0.5  ) {
vo=0;
dir=1;
}$I$(2).sim.updateVoltageSource$I$I$I$D(0, this.nodes[1], this.pins[1].voltSource, vo);
var cur1=$I$(2).sim.nodeList.size$() + this.pins[4].voltSource;
var cur2=$I$(2).sim.nodeList.size$() + this.pins[5].voltSource;
$I$(2).sim.stampMatrix$I$I$D(this.nodes[2], cur1, dir);
$I$(2).sim.stampMatrix$I$I$D(this.nodes[2], cur2, dir);
$I$(2).sim.stampMatrix$I$I$D(this.nodes[3], cur1, -dir);
$I$(2).sim.stampMatrix$I$I$D(this.nodes[3], cur2, -dir);
this.cDir=dir;
});

Clazz.newMeth(C$, 'computeCurrent$',  function () {
if (false) return;
var c=this.cDir * (this.pins[4].current + this.pins[5].current) + (this.volts[3] - this.volts[2]) / 1000000.0;
this.pins[2].current=-c;
this.pins[3].current=c;
this.pins[0].current=-this.pins[4].current;
});

Clazz.newMeth(C$, 'draw$java_awt_Graphics',  function (g) {
this.computeCurrent$();
this.drawChip$java_awt_Graphics(g);
});

Clazz.newMeth(C$, 'getPostCount$',  function () {
return 6;
});

Clazz.newMeth(C$, 'getVoltageSourceCount$',  function () {
return 3;
});

Clazz.newMeth(C$, 'getDumpType$',  function () {
return 158;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v2');//Created 2024-02-12 21:09:32 Java2ScriptVisitor version 5.0.1-v2 net.sf.j2s.core.jar version 5.0.1-v2

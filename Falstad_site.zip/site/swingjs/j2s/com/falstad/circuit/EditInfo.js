(function(){var P$=Clazz.newPackage("com.falstad.circuit"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "EditInfo");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['Z',['newDialog','forceLargeM','dimensionless'],'D',['value','minval','maxval'],'S',['name','text'],'O',['textf','a2s.TextField','bar','a2s.Scrollbar','choice','a2s.Choice','checkbox','a2s.Checkbox']]]

Clazz.newMeth(C$, 'c$$S$D$D$D',  function (n, val, mn, mx) {
;C$.$init$.apply(this);
this.name=n;
this.value=val;
if (mn == 0  && mx == 0   && val > 0  ) {
this.minval=1.0E10;
while (this.minval > val / 100 )this.minval/=10.0;

this.maxval=this.minval * 1000;
} else {
this.minval=mn;
this.maxval=mx;
}this.forceLargeM=this.name.indexOf$S("(ohms)") > 0 || this.name.indexOf$S("(Hz)") > 0 ;
this.dimensionless=false;
}, 1);

Clazz.newMeth(C$, 'setDimensionless$',  function () {
this.dimensionless=true;
return this;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v2');//Created 2024-02-12 21:09:31 Java2ScriptVisitor version 5.0.1-v2 net.sf.j2s.core.jar version 5.0.1-v2

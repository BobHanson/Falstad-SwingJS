(function(){var P$=Clazz.newPackage("com.falstad.circuit"),I$=[[0,'com.falstad.circuit.CircuitElm','java.awt.Color','com.falstad.circuit.EditInfo','a2s.Choice']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "VoltageElm", null, 'com.falstad.circuit.CircuitElm');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.circleSize=17;
},1);

C$.$fields$=[['D',['frequency','maxVoltage','freqTimeZero','bias','phaseShift','dutyCycle'],'I',['waveform','circleSize']]]

Clazz.newMeth(C$, 'c$$I$I$I',  function (xx, yy, wf) {
;C$.superclazz.c$$I$I.apply(this,[xx, yy]);C$.$init$.apply(this);
this.waveform=wf;
this.maxVoltage=5;
this.frequency=40;
this.dutyCycle=0.5;
this.reset$();
}, 1);

Clazz.newMeth(C$, 'c$$I$I$I$I$I$java_util_StringTokenizer',  function (xa, ya, xb, yb, f, st) {
;C$.superclazz.c$$I$I$I$I$I.apply(this,[xa, ya, xb, yb, f]);C$.$init$.apply(this);
this.maxVoltage=5;
this.frequency=40;
this.waveform=0;
this.dutyCycle=0.5;
try {
this.waveform= new Integer(st.nextToken$()).intValue$();
this.frequency= new Double(st.nextToken$()).doubleValue$();
this.maxVoltage= new Double(st.nextToken$()).doubleValue$();
this.bias= new Double(st.nextToken$()).doubleValue$();
this.phaseShift= new Double(st.nextToken$()).doubleValue$();
this.dutyCycle= new Double(st.nextToken$()).doubleValue$();
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
}
if ((this.flags & 2) != 0) {
this.flags&=~2;
this.phaseShift=1.5707963267948966;
}this.reset$();
}, 1);

Clazz.newMeth(C$, 'getDumpType$',  function () {
return "v".$c();
});

Clazz.newMeth(C$, 'dump$',  function () {
return C$.superclazz.prototype.dump$.apply(this, []) + " " + this.waveform + " " + new Double(this.frequency).toString() + " " + new Double(this.maxVoltage).toString() + " " + new Double(this.bias).toString() + " " + new Double(this.phaseShift).toString() + " " + new Double(this.dutyCycle).toString() ;
});

Clazz.newMeth(C$, 'reset$',  function () {
this.freqTimeZero=0;
this.curcount=0;
});

Clazz.newMeth(C$, 'triangleFunc$D',  function (x) {
if (x < 3.141592653589793 ) return x * (0.6366197723675814) - 1;
return 1 - (x - 3.141592653589793) * (0.6366197723675814);
});

Clazz.newMeth(C$, 'stamp$',  function () {
if (this.waveform == 0) $I$(1).sim.stampVoltageSource$I$I$I$D(this.nodes[0], this.nodes[1], this.voltSource, this.getVoltage$());
 else $I$(1).sim.stampVoltageSource$I$I$I(this.nodes[0], this.nodes[1], this.voltSource);
});

Clazz.newMeth(C$, 'doStep$',  function () {
if (this.waveform != 0) $I$(1).sim.updateVoltageSource$I$I$I$D(this.nodes[0], this.nodes[1], this.voltSource, this.getVoltage$());
});

Clazz.newMeth(C$, 'getVoltage$',  function () {
var w=2 * 3.141592653589793 * ($I$(1).sim.t - this.freqTimeZero) * this.frequency  + this.phaseShift;
switch (this.waveform) {
case 0:
return this.maxVoltage + this.bias;
case 1:
return Math.sin(w) * this.maxVoltage + this.bias;
case 2:
return this.bias + ((w % (6.283185307179586) > (2 * 3.141592653589793 * this.dutyCycle ) ) ? -this.maxVoltage : this.maxVoltage);
case 3:
return this.bias + this.triangleFunc$D(w % (6.283185307179586)) * this.maxVoltage;
case 4:
return this.bias + (w % (6.283185307179586)) * (this.maxVoltage / 3.141592653589793) - this.maxVoltage;
case 5:
return ((w % (6.283185307179586)) < 1 ) ? this.maxVoltage + this.bias : this.bias;
default:
return 0;
}
});

Clazz.newMeth(C$, 'setPoints$',  function () {
C$.superclazz.prototype.setPoints$.apply(this, []);
this.calcLeads$I((this.waveform == 0 || this.waveform == 6 ) ? 8 : 34);
});

Clazz.newMeth(C$, 'draw$java_awt_Graphics',  function (g) {
this.setBbox$I$I$I$I(this.x, this.y, this.x2, this.y2);
this.draw2Leads$java_awt_Graphics(g);
if (this.waveform == 0) {
this.setPowerColor$java_awt_Graphics$Z(g, false);
this.setVoltageColor$java_awt_Graphics$D(g, this.volts[0]);
this.interpPoint2$java_awt_Point$java_awt_Point$java_awt_Point$java_awt_Point$D$D(this.lead1, this.lead2, $I$(1).ps1, $I$(1).ps2, 0, 10);
$I$(1,"drawThickLine$java_awt_Graphics$java_awt_Point$java_awt_Point",[g, $I$(1).ps1, $I$(1).ps2]);
this.setVoltageColor$java_awt_Graphics$D(g, this.volts[1]);
var hs=16;
this.setBbox$java_awt_Point$java_awt_Point$D(this.point1, this.point2, hs);
this.interpPoint2$java_awt_Point$java_awt_Point$java_awt_Point$java_awt_Point$D$D(this.lead1, this.lead2, $I$(1).ps1, $I$(1).ps2, 1, hs);
$I$(1,"drawThickLine$java_awt_Graphics$java_awt_Point$java_awt_Point",[g, $I$(1).ps1, $I$(1).ps2]);
} else {
this.setBbox$java_awt_Point$java_awt_Point$D(this.point1, this.point2, 17);
this.interpPoint$java_awt_Point$java_awt_Point$java_awt_Point$D(this.lead1, this.lead2, $I$(1).ps1, 0.5);
this.drawWaveform$java_awt_Graphics$java_awt_Point(g, $I$(1).ps1);
}this.updateDotCount$();
if ($I$(1).sim.dragElm !== this ) {
if (this.waveform == 0) this.drawDots$java_awt_Graphics$java_awt_Point$java_awt_Point$D(g, this.point1, this.point2, this.curcount);
 else {
this.drawDots$java_awt_Graphics$java_awt_Point$java_awt_Point$D(g, this.point1, this.lead1, this.curcount);
this.drawDots$java_awt_Graphics$java_awt_Point$java_awt_Point$D(g, this.point2, this.lead2, -this.curcount);
}}this.drawPosts$java_awt_Graphics(g);
});

Clazz.newMeth(C$, 'drawWaveform$java_awt_Graphics$java_awt_Point',  function (g, center) {
g.setColor$java_awt_Color(this.needsHighlight$() ? $I$(1).selectColor : $I$(2).gray);
this.setPowerColor$java_awt_Graphics$Z(g, false);
var xc=center.x;
var yc=center.y;
$I$(1).drawThickCircle$java_awt_Graphics$I$I$I(g, xc, yc, 17);
var wl=8;
this.adjustBbox$I$I$I$I(xc - 17, yc - 17, xc + 17, yc + 17);
var xc2;
switch (this.waveform) {
case 0:
{
break;
}case 2:
xc2=((wl * 2 * this.dutyCycle  - wl + xc)|0);
xc2=$I$(1,"max$I$I",[xc - wl + 3, $I$(1).min$I$I(xc + wl - 3, xc2)]);
$I$(1).drawThickLine$java_awt_Graphics$I$I$I$I(g, xc - wl, yc - wl, xc - wl, yc);
$I$(1).drawThickLine$java_awt_Graphics$I$I$I$I(g, xc - wl, yc - wl, xc2, yc - wl);
$I$(1).drawThickLine$java_awt_Graphics$I$I$I$I(g, xc2, yc - wl, xc2, yc + wl);
$I$(1).drawThickLine$java_awt_Graphics$I$I$I$I(g, xc + wl, yc + wl, xc2, yc + wl);
$I$(1).drawThickLine$java_awt_Graphics$I$I$I$I(g, xc + wl, yc, xc + wl, yc + wl);
break;
case 5:
yc+=(wl/2|0);
$I$(1).drawThickLine$java_awt_Graphics$I$I$I$I(g, xc - wl, yc - wl, xc - wl, yc);
$I$(1,"drawThickLine$java_awt_Graphics$I$I$I$I",[g, xc - wl, yc - wl, xc - (wl/2|0), yc - wl]);
$I$(1,"drawThickLine$java_awt_Graphics$I$I$I$I",[g, xc - (wl/2|0), yc - wl, xc - (wl/2|0), yc]);
$I$(1,"drawThickLine$java_awt_Graphics$I$I$I$I",[g, xc - (wl/2|0), yc, xc + wl, yc]);
break;
case 4:
$I$(1).drawThickLine$java_awt_Graphics$I$I$I$I(g, xc, yc - wl, xc - wl, yc);
$I$(1).drawThickLine$java_awt_Graphics$I$I$I$I(g, xc, yc - wl, xc, yc + wl);
$I$(1).drawThickLine$java_awt_Graphics$I$I$I$I(g, xc, yc + wl, xc + wl, yc);
break;
case 3:
{
var xl=5;
$I$(1).drawThickLine$java_awt_Graphics$I$I$I$I(g, xc - xl * 2, yc, xc - xl, yc - wl);
$I$(1).drawThickLine$java_awt_Graphics$I$I$I$I(g, xc - xl, yc - wl, xc, yc);
$I$(1).drawThickLine$java_awt_Graphics$I$I$I$I(g, xc, yc, xc + xl, yc + wl);
$I$(1).drawThickLine$java_awt_Graphics$I$I$I$I(g, xc + xl, yc + wl, xc + xl * 2, yc);
break;
}case 1:
{
var i;
var xl=10;
var ox=-1;
var oy=-1;
for (i=-xl; i <= xl; i++) {
var yy=yc + ((0.95 * Math.sin(i * 3.141592653589793 / xl) * wl )|0);
if (ox != -1) $I$(1).drawThickLine$java_awt_Graphics$I$I$I$I(g, ox, oy, xc + i, yy);
ox=xc + i;
oy=yy;
}
break;
}}
if ($I$(1).sim.showValuesCheckItem.getState$()) {
var s=$I$(1).getShortUnitText$D$S(this.frequency, "Hz");
if (this.dx == 0 || this.dy == 0 ) this.drawValues$java_awt_Graphics$S$D(g, s, 17);
}});

Clazz.newMeth(C$, 'getVoltageSourceCount$',  function () {
return 1;
});

Clazz.newMeth(C$, 'getPower$',  function () {
return -this.getVoltageDiff$() * this.current;
});

Clazz.newMeth(C$, 'getVoltageDiff$',  function () {
return this.volts[1] - this.volts[0];
});

Clazz.newMeth(C$, 'getInfo$SA',  function (arr) {
switch (this.waveform) {
case 0:
case 6:
arr[0]="voltage source";
break;
case 1:
arr[0]="A/C source";
break;
case 2:
arr[0]="square wave gen";
break;
case 5:
arr[0]="pulse gen";
break;
case 4:
arr[0]="sawtooth gen";
break;
case 3:
arr[0]="triangle gen";
break;
}
arr[1]="I = " + $I$(1,"getCurrentText$D",[this.getCurrent$()]);
arr[2]=((Clazz.instanceOf(this, "com.falstad.circuit.RailElm")) ? "V = " : "Vd = ") + $I$(1,"getVoltageText$D",[this.getVoltageDiff$()]);
if (this.waveform != 0 && this.waveform != 6 ) {
arr[3]="f = " + $I$(1).getUnitText$D$S(this.frequency, "Hz");
arr[4]="Vmax = " + $I$(1).getVoltageText$D(this.maxVoltage);
var i=5;
if (this.bias != 0 ) arr[i++]="Voff = " + $I$(1).getVoltageText$D(this.bias);
 else if (this.frequency > 500 ) arr[i++]="wavelength = " + $I$(1).getUnitText$D$S(2.9979E8 / this.frequency, "m");
arr[i++]="P = " + $I$(1,"getUnitText$D$S",[this.getPower$(), "W"]);
}});

Clazz.newMeth(C$, 'getEditInfo$I',  function (n) {
if (n == 0) return Clazz.new_([this.waveform == 0 ? "Voltage" : "Max Voltage", this.maxVoltage, -20, 20],$I$(3,1).c$$S$D$D$D);
if (n == 1) {
var ei=Clazz.new_($I$(3,1).c$$S$D$D$D,["Waveform", this.waveform, -1, -1]);
ei.choice=Clazz.new_($I$(4,1));
ei.choice.add$S("D/C");
ei.choice.add$S("A/C");
ei.choice.add$S("Square Wave");
ei.choice.add$S("Triangle");
ei.choice.add$S("Sawtooth");
ei.choice.add$S("Pulse");
ei.choice.select$I(this.waveform);
return ei;
}if (this.waveform == 0) return null;
if (n == 2) return Clazz.new_(["Frequency (Hz)", this.frequency, 4, 500],$I$(3,1).c$$S$D$D$D);
if (n == 3) return Clazz.new_(["DC Offset (V)", this.bias, -20, 20],$I$(3,1).c$$S$D$D$D);
if (n == 4) return Clazz.new_(["Phase Offset (degrees)", this.phaseShift * 180 / 3.141592653589793, -180, 180],$I$(3,1).c$$S$D$D$D).setDimensionless$();
if (n == 5 && this.waveform == 2 ) return Clazz.new_($I$(3,1).c$$S$D$D$D,["Duty Cycle", this.dutyCycle * 100, 0, 100]).setDimensionless$();
return null;
});

Clazz.newMeth(C$, 'setEditValue$I$com_falstad_circuit_EditInfo',  function (n, ei) {
if (n == 0) this.maxVoltage=ei.value;
if (n == 3) this.bias=ei.value;
if (n == 2) {
var oldfreq=this.frequency;
this.frequency=ei.value;
var maxfreq=1 / (8 * $I$(1).sim.timeStep);
if (this.frequency > maxfreq ) this.frequency=maxfreq;
var adj=this.frequency - oldfreq;
this.freqTimeZero=$I$(1).sim.t - oldfreq * ($I$(1).sim.t - this.freqTimeZero) / this.frequency;
}if (n == 1) {
var ow=this.waveform;
this.waveform=ei.choice.getSelectedIndex$();
if (this.waveform == 0 && ow != 0 ) {
ei.newDialog=true;
this.bias=0;
} else if (this.waveform != 0 && ow == 0 ) {
ei.newDialog=true;
}if ((this.waveform == 2 || ow == 2 ) && this.waveform != ow ) ei.newDialog=true;
this.setPoints$();
}if (n == 4) this.phaseShift=ei.value * 3.141592653589793 / 180;
if (n == 5) this.dutyCycle=ei.value * 0.01;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v2');//Created 2024-02-12 21:09:32 Java2ScriptVisitor version 5.0.1-v2 net.sf.j2s.core.jar version 5.0.1-v2

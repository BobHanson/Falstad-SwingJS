(function(){var P$=Clazz.newPackage("com.falstad.circuit"),I$=[[0,'com.falstad.circuit.CircuitElm','java.awt.Font','com.falstad.circuit.EditInfo','a2s.Checkbox']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "ProbeElm", null, 'com.falstad.circuit.CircuitElm');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['center','java.awt.Point']]]

Clazz.newMeth(C$, 'c$$I$I',  function (xx, yy) {
;C$.superclazz.c$$I$I.apply(this,[xx, yy]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$I$I$I$I$I$java_util_StringTokenizer',  function (xa, ya, xb, yb, f, st) {
;C$.superclazz.c$$I$I$I$I$I.apply(this,[xa, ya, xb, yb, f]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'getDumpType$',  function () {
return "p".$c();
});

Clazz.newMeth(C$, 'setPoints$',  function () {
C$.superclazz.prototype.setPoints$.apply(this, []);
if (this.point2.y < this.point1.y) {
var x=this.point1;
this.point1=this.point2;
this.point2=x;
}this.center=this.interpPoint$java_awt_Point$java_awt_Point$D(this.point1, this.point2, 0.5);
});

Clazz.newMeth(C$, 'draw$java_awt_Graphics',  function (g) {
var hs=8;
this.setBbox$java_awt_Point$java_awt_Point$D(this.point1, this.point2, hs);
var selected=(this.needsHighlight$() || $I$(1).sim.plotYElm === this  );
var len=(selected || $I$(1).sim.dragElm === this  ) ? 16 : this.dn - 32;
this.calcLeads$I((len|0));
this.setVoltageColor$java_awt_Graphics$D(g, this.volts[0]);
if (selected) g.setColor$java_awt_Color($I$(1).selectColor);
$I$(1).drawThickLine$java_awt_Graphics$java_awt_Point$java_awt_Point(g, this.point1, this.lead1);
this.setVoltageColor$java_awt_Graphics$D(g, this.volts[1]);
if (selected) g.setColor$java_awt_Color($I$(1).selectColor);
$I$(1).drawThickLine$java_awt_Graphics$java_awt_Point$java_awt_Point(g, this.lead2, this.point2);
var f=Clazz.new_($I$(2,1).c$$S$I$I,["SansSerif", 1, 14]);
g.setFont$java_awt_Font(f);
if (this === $I$(1).sim.plotXElm ) this.drawCenteredText$java_awt_Graphics$S$I$I$Z(g, "X", this.center.x, this.center.y, true);
if (this === $I$(1).sim.plotYElm ) this.drawCenteredText$java_awt_Graphics$S$I$I$Z(g, "Y", this.center.x, this.center.y, true);
if (this.mustShowVoltage$()) {
var s=$I$(1).getShortUnitText$D$S(this.volts[0], "V");
this.drawValues$java_awt_Graphics$S$D(g, s, 4);
}this.drawPosts$java_awt_Graphics(g);
});

Clazz.newMeth(C$, 'mustShowVoltage$',  function () {
return (this.flags & 1) != 0;
});

Clazz.newMeth(C$, 'getInfo$SA',  function (arr) {
arr[0]="scope probe";
arr[1]="Vd = " + $I$(1,"getVoltageText$D",[this.getVoltageDiff$()]);
});

Clazz.newMeth(C$, 'getConnection$I$I',  function (n1, n2) {
return false;
});

Clazz.newMeth(C$, 'getEditInfo$I',  function (n) {
if (n == 0) {
var ei=Clazz.new_($I$(3,1).c$$S$D$D$D,["", 0, -1, -1]);
ei.checkbox=Clazz.new_(["Show Voltage", this.mustShowVoltage$()],$I$(4,1).c$$S$Z);
return ei;
}return null;
});

Clazz.newMeth(C$, 'setEditValue$I$com_falstad_circuit_EditInfo',  function (n, ei) {
if (n == 0) {
if (ei.checkbox.getState$()) this.flags=1;
 else this.flags&=~1;
}});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v2');//Created 2024-02-12 21:09:31 Java2ScriptVisitor version 5.0.1-v2 net.sf.j2s.core.jar version 5.0.1-v2

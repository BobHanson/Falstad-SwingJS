(function(){var P$=Clazz.newPackage("com.falstad.circuit"),I$=[['java.util.Vector']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "CircuitNode");

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.x = 0;
this.y = 0;
this.links = null;
this.internal = false;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.$init$.apply(this);
this.links = Clazz.new_((I$[1]||$incl$(1)));
}, 1);
})();
//Created 2018-03-18 11:47:35

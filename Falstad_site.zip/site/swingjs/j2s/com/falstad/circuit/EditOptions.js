(function(){var P$=Clazz.newPackage("com.falstad.circuit"),I$=[['com.falstad.circuit.EditInfo','com.falstad.circuit.CircuitElm']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "EditOptions", null, null, 'com.falstad.circuit.Editable');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.sim = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$com_falstad_circuit_CirSim', function (s) {
C$.$init$.apply(this);
this.sim = s;
}, 1);

Clazz.newMeth(C$, 'getEditInfo$I', function (n) {
if (n == 0) return Clazz.new_((I$[1]||$incl$(1)).c$$S$D$D$D,["Time step size (s)", this.sim.timeStep, 0, 0]);
if (n == 1) return Clazz.new_((I$[1]||$incl$(1)).c$$S$D$D$D,["Range for voltage color (V)", (I$[2]||$incl$(2)).voltageRange, 0, 0]);
return null;
});

Clazz.newMeth(C$, 'setEditValue$I$com_falstad_circuit_EditInfo', function (n, ei) {
if (n == 0 && ei.value > 0  ) this.sim.timeStep = ei.value;
if (n == 1 && ei.value > 0  ) (I$[2]||$incl$(2)).voltageRange = ei.value;
});

Clazz.newMeth(C$);
})();
//Created 2018-03-18 11:47:36

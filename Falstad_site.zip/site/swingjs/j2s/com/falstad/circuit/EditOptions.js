(function(){var P$=Clazz.newPackage("com.falstad.circuit"),I$=[[0,'com.falstad.circuit.EditInfo','com.falstad.circuit.CircuitElm']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "EditOptions", null, null, 'com.falstad.circuit.Editable');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['sim','com.falstad.circuit.CirSim']]]

Clazz.newMeth(C$, 'c$$com_falstad_circuit_CirSim',  function (s) {
;C$.$init$.apply(this);
this.sim=s;
}, 1);

Clazz.newMeth(C$, 'getEditInfo$I',  function (n) {
if (n == 0) return Clazz.new_(["Time step size (s)", this.sim.timeStep, 0, 0],$I$(1,1).c$$S$D$D$D);
if (n == 1) return Clazz.new_(["Range for voltage color (V)", $I$(2).voltageRange, 0, 0],$I$(1,1).c$$S$D$D$D);
return null;
});

Clazz.newMeth(C$, 'setEditValue$I$com_falstad_circuit_EditInfo',  function (n, ei) {
if (n == 0 && ei.value > 0  ) this.sim.timeStep=ei.value;
if (n == 1 && ei.value > 0  ) $I$(2).voltageRange=ei.value;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v2');//Created 2024-02-12 21:09:31 Java2ScriptVisitor version 5.0.1-v2 net.sf.j2s.core.jar version 5.0.1-v2

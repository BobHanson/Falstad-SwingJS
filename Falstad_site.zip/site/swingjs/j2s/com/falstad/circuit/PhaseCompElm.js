(function(){var P$=Clazz.newPackage("com.falstad.circuit"),I$=[[0,['com.falstad.circuit.ChipElm','.Pin'],'com.falstad.circuit.CircuitElm']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "PhaseCompElm", null, 'com.falstad.circuit.ChipElm');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['Z',['ff1','ff2']]]

Clazz.newMeth(C$, 'c$$I$I',  function (xx, yy) {
;C$.superclazz.c$$I$I.apply(this,[xx, yy]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$I$I$I$I$I$java_util_StringTokenizer',  function (xa, ya, xb, yb, f, st) {
;C$.superclazz.c$$I$I$I$I$I$java_util_StringTokenizer.apply(this,[xa, ya, xb, yb, f, st]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'getChipName$',  function () {
return "phase comparator";
});

Clazz.newMeth(C$, 'setupPins$',  function () {
this.sizeX=2;
this.sizeY=2;
this.pins=Clazz.array($I$(1), [3]);
this.pins[0]=Clazz.new_($I$(1,1).c$$I$I$S,[this, null, 0, 2, "I1"]);
this.pins[1]=Clazz.new_($I$(1,1).c$$I$I$S,[this, null, 1, 2, "I2"]);
this.pins[2]=Clazz.new_($I$(1,1).c$$I$I$S,[this, null, 0, 3, "O"]);
this.pins[2].output=true;
});

Clazz.newMeth(C$, 'nonLinear$',  function () {
return true;
});

Clazz.newMeth(C$, 'stamp$',  function () {
var vn=$I$(2).sim.nodeList.size$() + this.pins[2].voltSource;
$I$(2).sim.stampNonLinear$I(vn);
$I$(2).sim.stampNonLinear$I(0);
$I$(2).sim.stampNonLinear$I(this.nodes[2]);
});

Clazz.newMeth(C$, 'doStep$',  function () {
var v1=this.volts[0] > 2.5 ;
var v2=this.volts[1] > 2.5 ;
if (v1 && !this.pins[0].value ) this.ff1=true;
if (v2 && !this.pins[1].value ) this.ff2=true;
if (this.ff1 && this.ff2 ) this.ff1=this.ff2=false;
var out=(this.ff1) ? 5 : (this.ff2) ? 0 : -1;
if (out != -1 ) $I$(2).sim.stampVoltageSource$I$I$I$D(0, this.nodes[2], this.pins[2].voltSource, out);
 else {
var vn=$I$(2).sim.nodeList.size$() + this.pins[2].voltSource;
$I$(2).sim.stampMatrix$I$I$D(vn, vn, 1);
}this.pins[0].value=v1;
this.pins[1].value=v2;
});

Clazz.newMeth(C$, 'getPostCount$',  function () {
return 3;
});

Clazz.newMeth(C$, 'getVoltageSourceCount$',  function () {
return 1;
});

Clazz.newMeth(C$, 'getDumpType$',  function () {
return 161;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v2');//Created 2024-02-12 21:09:31 Java2ScriptVisitor version 5.0.1-v2 net.sf.j2s.core.jar version 5.0.1-v2

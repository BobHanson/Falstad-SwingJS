(function(){var P$=Clazz.newPackage("com.falstad.circuit"),I$=[[0,'com.falstad.circuit.CircuitElm','com.falstad.circuit.EditInfo']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "CurrentElm", null, 'com.falstad.circuit.CircuitElm');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['D',['currentValue'],'O',['arrow','java.awt.Polygon','ashaft1','java.awt.Point','+ashaft2','+center']]]

Clazz.newMeth(C$, 'c$$I$I',  function (xx, yy) {
;C$.superclazz.c$$I$I.apply(this,[xx, yy]);C$.$init$.apply(this);
this.currentValue=0.01;
}, 1);

Clazz.newMeth(C$, 'c$$I$I$I$I$I$java_util_StringTokenizer',  function (xa, ya, xb, yb, f, st) {
;C$.superclazz.c$$I$I$I$I$I.apply(this,[xa, ya, xb, yb, f]);C$.$init$.apply(this);
try {
this.currentValue= new Double(st.nextToken$()).doubleValue$();
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
this.currentValue=0.01;
} else {
throw e;
}
}
}, 1);

Clazz.newMeth(C$, 'dump$',  function () {
return C$.superclazz.prototype.dump$.apply(this, []) + " " + new Double(this.currentValue).toString() ;
});

Clazz.newMeth(C$, 'getDumpType$',  function () {
return "i".$c();
});

Clazz.newMeth(C$, 'setPoints$',  function () {
C$.superclazz.prototype.setPoints$.apply(this, []);
this.calcLeads$I(26);
this.ashaft1=this.interpPoint$java_awt_Point$java_awt_Point$D(this.lead1, this.lead2, 0.25);
this.ashaft2=this.interpPoint$java_awt_Point$java_awt_Point$D(this.lead1, this.lead2, 0.6);
this.center=this.interpPoint$java_awt_Point$java_awt_Point$D(this.lead1, this.lead2, 0.5);
var p2=this.interpPoint$java_awt_Point$java_awt_Point$D(this.lead1, this.lead2, 0.75);
this.arrow=this.calcArrow$java_awt_Point$java_awt_Point$D$D(this.center, p2, 4, 4);
});

Clazz.newMeth(C$, 'draw$java_awt_Graphics',  function (g) {
var cr=12;
this.draw2Leads$java_awt_Graphics(g);
this.setVoltageColor$java_awt_Graphics$D(g, (this.volts[0] + this.volts[1]) / 2);
this.setPowerColor$java_awt_Graphics$Z(g, false);
$I$(1).drawThickCircle$java_awt_Graphics$I$I$I(g, this.center.x, this.center.y, cr);
$I$(1).drawThickLine$java_awt_Graphics$java_awt_Point$java_awt_Point(g, this.ashaft1, this.ashaft2);
g.fillPolygon$java_awt_Polygon(this.arrow);
this.setBbox$java_awt_Point$java_awt_Point$D(this.point1, this.point2, cr);
this.doDots$java_awt_Graphics(g);
if ($I$(1).sim.showValuesCheckItem.getState$()) {
var s=$I$(1).getShortUnitText$D$S(this.currentValue, "A");
if (this.dx == 0 || this.dy == 0 ) this.drawValues$java_awt_Graphics$S$D(g, s, cr);
}this.drawPosts$java_awt_Graphics(g);
});

Clazz.newMeth(C$, 'stamp$',  function () {
this.current=this.currentValue;
$I$(1).sim.stampCurrentSource$I$I$D(this.nodes[0], this.nodes[1], this.current);
});

Clazz.newMeth(C$, 'getEditInfo$I',  function (n) {
if (n == 0) return Clazz.new_(["Current (A)", this.currentValue, 0, 0.1],$I$(2,1).c$$S$D$D$D);
return null;
});

Clazz.newMeth(C$, 'setEditValue$I$com_falstad_circuit_EditInfo',  function (n, ei) {
this.currentValue=ei.value;
});

Clazz.newMeth(C$, 'getInfo$SA',  function (arr) {
arr[0]="current source";
this.getBasicInfo$SA(arr);
});

Clazz.newMeth(C$, 'getVoltageDiff$',  function () {
return this.volts[1] - this.volts[0];
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v2');//Created 2024-02-12 21:09:31 Java2ScriptVisitor version 5.0.1-v2 net.sf.j2s.core.jar version 5.0.1-v2

(function(){var P$=Clazz.newPackage("com.falstad.circuit"),I$=[];
var C$=Clazz.newInterface(P$, "Editable");
})();
//Created 2018-03-18 11:47:36

(function(){var P$=Clazz.newPackage("com.falstad.circuit"),I$=[['com.falstad.circuit.OpAmpElm']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "OpAmpSwapElm", null, 'com.falstad.circuit.OpAmpElm');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$I$I', function (xx, yy) {
C$.superclazz.c$$I$I.apply(this, [xx, yy]);
C$.$init$.apply(this);
this.flags = this.flags|(1);
}, 1);

Clazz.newMeth(C$, 'getDumpClass', function () {
return Clazz.getClass((I$[1]||$incl$(1)));
});

Clazz.newMeth(C$);
})();
//Created 2018-03-18 11:47:37

(function(){var P$=Clazz.newPackage("com.falstad"),I$=[['java.awt.Dimension',['com.falstad.Gas','.Setup1Equal'],['com.falstad.Gas','.Setup1Extreme'],['com.falstad.Gas','.Setup1Single'],['com.falstad.Gas','.Setup1Small'],['com.falstad.Gas','.Setup2Random'],['com.falstad.Gas','.Setup2Equal'],['com.falstad.Gas','.Setup3Random'],['com.falstad.Gas','.Setup3Equal'],['com.falstad.Gas','.SetupBrownian'],['com.falstad.Gas','.SetupExpansion'],'java.util.Vector',['com.falstad.Gas','.Setup1Random'],'java.text.NumberFormat','java.awt.Color','com.falstad.GasLayout','com.falstad.GasCanvas','com.falstad.HistogramCanvas','a2s.Choice','a2s.Checkbox','a2s.Button','a2s.Label','a2s.Scrollbar','java.util.Random',['com.falstad.Gas','.Molecule']]],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "GasCanvas", null, 'a2s.Canvas');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.pg = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$com_falstad_Gas', function (p) {
Clazz.super_(C$, this,1);
this.pg = p;
}, 1);

Clazz.newMeth(C$, 'getPreferredSize', function () {
return Clazz.new_((I$[1]||$incl$(1)).c$$I$I,[300, 400]);
});

Clazz.newMeth(C$, 'update$java_awt_Graphics', function (g) {
this.pg.updateGas$java_awt_Graphics(g);
});

Clazz.newMeth(C$, 'paintComponent$java_awt_Graphics', function (g) {
this.pg.updateGas$java_awt_Graphics(g);
});

Clazz.newMeth(C$);
})();
//Created 2018-03-18 11:47:22

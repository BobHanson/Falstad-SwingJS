(function(){var P$=Clazz.newPackage("com.falstad"),I$=[['java.awt.Dimension','com.falstad.EMWave2Frame',['com.falstad.EMWave2Frame','.DoubleSourceSetup'],['com.falstad.EMWave2Frame','.PlaneWaveSetup'],['com.falstad.EMWave2Frame','.IntersectingPlaneWavesSetup'],['com.falstad.EMWave2Frame','.SingleWireSetup'],['com.falstad.EMWave2Frame','.DoubleWireSetup'],['com.falstad.EMWave2Frame','.DipoleWireSetup'],['com.falstad.EMWave2Frame','.MagnetPairSetup'],['com.falstad.EMWave2Frame','.MagnetPairOppSetup'],['com.falstad.EMWave2Frame','.MagnetPairStackedSetup'],['com.falstad.EMWave2Frame','.MagnetPairStackedOppSetup'],['com.falstad.EMWave2Frame','.UniformFieldSetup'],['com.falstad.EMWave2Frame','.ApertureFieldSetup'],['com.falstad.EMWave2Frame','.SolenoidSetup'],['com.falstad.EMWave2Frame','.ToroidalSolenoidSetup'],['com.falstad.EMWave2Frame','.CylinderSetup'],['com.falstad.EMWave2Frame','.ThickWireSetup'],['com.falstad.EMWave2Frame','.HoleInWire1Setup'],['com.falstad.EMWave2Frame','.HoleInWire2Setup'],['com.falstad.EMWave2Frame','.FerromagnetSetup'],['com.falstad.EMWave2Frame','.DiamagnetSetup'],['com.falstad.EMWave2Frame','.MeissnerEffectSetup'],['com.falstad.EMWave2Frame','.HorseshoeSetup'],['com.falstad.EMWave2Frame','.Horseshoe2Setup'],['com.falstad.EMWave2Frame','.MagneticShielding1Setup'],['com.falstad.EMWave2Frame','.MagneticShielding2Setup'],['com.falstad.EMWave2Frame','.MagneticShielding3Setup'],['com.falstad.EMWave2Frame','.MagneticShielding4Setup'],['com.falstad.EMWave2Frame','.MagneticCircuit1Setup'],['com.falstad.EMWave2Frame','.MagneticCircuit2Setup'],['com.falstad.EMWave2Frame','.MonopoleAttemptSetup'],['com.falstad.EMWave2Frame','.QuadrupoleLensSetup'],['com.falstad.EMWave2Frame','.HalbachArraySetup'],['com.falstad.EMWave2Frame','.HalbachArray2Setup'],['com.falstad.EMWave2Frame','.HalbachArray3Setup'],['com.falstad.EMWave2Frame','.HalbachArray4Setup'],['com.falstad.EMWave2Frame','.DielectricSetup'],['com.falstad.EMWave2Frame','.ConductReflectSetup'],['com.falstad.EMWave2Frame','.Conduct2ReflectSetup'],['com.falstad.EMWave2Frame','.SkinEffect1Setup'],['com.falstad.EMWave2Frame','.SkinEffect2Setup'],['com.falstad.EMWave2Frame','.ResonantAbsSetup'],['com.falstad.EMWave2Frame','.Dispersion1Setup'],['com.falstad.EMWave2Frame','.Dispersion2Setup'],['com.falstad.EMWave2Frame','.Dispersion3Setup'],['com.falstad.EMWave2Frame','.Dispersion4Setup'],['com.falstad.EMWave2Frame','.DiffusionSetup'],['com.falstad.EMWave2Frame','.OscRingSetup'],['com.falstad.EMWave2Frame','.OscRingPairSetup'],['com.falstad.EMWave2Frame','.OscRingInductionSetup'],['com.falstad.EMWave2Frame','.WireInductionSetup'],['com.falstad.EMWave2Frame','.OscRingEddy1Setup'],['com.falstad.EMWave2Frame','.OscRingEddy2Setup'],['com.falstad.EMWave2Frame','.WireEddy1Setup'],['com.falstad.EMWave2Frame','.WireEddy2Setup'],['com.falstad.EMWave2Frame','.OscRingPermSetup'],['com.falstad.EMWave2Frame','.SolenoidOscSetup'],['com.falstad.EMWave2Frame','.TransformerSetup'],['com.falstad.EMWave2Frame','.ToroidalSolenoidOscSetup'],['com.falstad.EMWave2Frame','.CoaxCableSetup'],['com.falstad.EMWave2Frame','.CondInOscFieldSetup'],['com.falstad.EMWave2Frame','.MovingWireSetup'],['com.falstad.EMWave2Frame','.MovingWireTubeSetup'],['com.falstad.EMWave2Frame','.MovingMagnetSetup'],['com.falstad.EMWave2Frame','.RotatingMagnet1Setup'],['com.falstad.EMWave2Frame','.RotatingMagnet2Setup'],['com.falstad.EMWave2Frame','.Scattering1Setup'],['com.falstad.EMWave2Frame','.Scattering2Setup'],['com.falstad.EMWave2Frame','.BigModeSetup'],['com.falstad.EMWave2Frame','.OneByOneModesSetup'],['com.falstad.EMWave2Frame','.OneByNModesSetup'],['com.falstad.EMWave2Frame','.NByNModesSetup'],['com.falstad.EMWave2Frame','.OneByNModeCombosSetup'],['com.falstad.EMWave2Frame','.NByNModeCombosSetup'],['com.falstad.EMWave2Frame','.TriangleModesSetup'],['com.falstad.EMWave2Frame','.CircleModes1Setup'],['com.falstad.EMWave2Frame','.CircleModes2Setup'],['com.falstad.EMWave2Frame','.Waveguides1Setup'],['com.falstad.EMWave2Frame','.Waveguides2Setup'],['com.falstad.EMWave2Frame','.Waveguides3Setup'],['com.falstad.EMWave2Frame','.Waveguides4Setup'],['com.falstad.EMWave2Frame','.ResonantCavitiesSetup'],['com.falstad.EMWave2Frame','.SingleSlitSetup'],['com.falstad.EMWave2Frame','.DoubleSlitSetup'],['com.falstad.EMWave2Frame','.TripleSlitSetup'],['com.falstad.EMWave2Frame','.ObstacleSetup'],['com.falstad.EMWave2Frame','.HalfPlaneSetup'],['com.falstad.EMWave2Frame','.LloydsMirrorSetup'],'java.util.Vector',['com.falstad.EMWave2Frame','.SingleSourceSetup'],['com.falstad.EMWave2Frame','.OscSource'],'com.falstad.EMWave2Layout','com.falstad.EMWave2Canvas','a2s.Choice','a2s.Button','a2s.Checkbox','a2s.Label','a2s.Scrollbar','java.util.Random','java.awt.Color',['com.falstad.EMWave2Frame','.OscElement'],'java.awt.image.MemoryImageSource']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "EMWave2", null, 'a2s.Applet', 'java.awt.event.ComponentListener');
C$.ogf = null;

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.started = false;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.started = false;
}, 1);

Clazz.newMeth(C$, 'destroyFrame', function () {
if (C$.ogf != null ) C$.ogf.dispose();
C$.ogf = null;
this.repaint();
});

Clazz.newMeth(C$, 'init', function () {
this.showFrame();
});

Clazz.newMeth(C$, 'main', function (args) {
C$.ogf = Clazz.new_((I$[2]||$incl$(2)).c$$com_falstad_EMWave2,[null]);
C$.ogf.init();
}, 1);

Clazz.newMeth(C$, 'showFrame', function () {
if (C$.ogf == null ) {
this.started = true;
C$.ogf = Clazz.new_((I$[2]||$incl$(2)).c$$com_falstad_EMWave2,[this]);
C$.ogf.init();
this.repaint();
}});

Clazz.newMeth(C$, ['paint$java_awt_Graphics','paint'], function (g) {
C$.superclazz.prototype.paint$java_awt_Graphics.apply(this, [g]);
var s = "Applet is open in a separate window.";
if (!this.started) s = "Applet is starting.";
 else if (C$.ogf == null ) s = "Applet is finished.";
 else if (C$.ogf.useFrame) C$.ogf.triggerShow();
if (C$.ogf == null  || C$.ogf.useFrame ) g.drawString$S$I$I(s, 10, 30);
});

Clazz.newMeth(C$, ['componentHidden$java_awt_event_ComponentEvent','componentHidden'], function (e) {
});

Clazz.newMeth(C$, ['componentMoved$java_awt_event_ComponentEvent','componentMoved'], function (e) {
});

Clazz.newMeth(C$, ['componentShown$java_awt_event_ComponentEvent','componentShown'], function (e) {
});

Clazz.newMeth(C$, ['componentResized$java_awt_event_ComponentEvent','componentResized'], function (e) {
});

Clazz.newMeth(C$, 'destroy', function () {
if (C$.ogf != null ) C$.ogf.dispose();
C$.ogf = null;
this.repaint();
});

Clazz.newMeth(C$);
})();
//Created 2018-03-18 11:47:21

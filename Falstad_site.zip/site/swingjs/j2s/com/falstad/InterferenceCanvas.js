(function(){var P$=Clazz.newPackage("com.falstad"),p$1={},I$=[[0,'java.awt.Dimension','com.falstad.InterferenceFrame','java.text.NumberFormat','com.falstad.InterferenceLayout','com.falstad.InterferenceCanvas','a2s.Checkbox','a2s.Label','a2s.Scrollbar','java.awt.Color','javajs.util.JSAudioThread','javax.sound.sampled.AudioFormat']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "InterferenceCanvas", null, 'a2s.Canvas');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['pg','com.falstad.InterferenceFrame']]]

Clazz.newMeth(C$, 'c$$com_falstad_InterferenceFrame',  function (p) {
Clazz.super_(C$, this);
this.pg=p;
}, 1);

Clazz.newMeth(C$, 'getPreferredSize$',  function () {
return Clazz.new_($I$(1,1).c$$I$I,[300, 400]);
});

Clazz.newMeth(C$, 'update$java_awt_Graphics',  function (g) {
this.pg.updateInterference$java_awt_Graphics(g);
});

Clazz.newMeth(C$, 'paintComponent$java_awt_Graphics',  function (g) {
this.pg.updateInterference$java_awt_Graphics(g);
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v2');//Created 2024-02-12 21:09:28 Java2ScriptVisitor version 5.0.1-v2 net.sf.j2s.core.jar version 5.0.1-v2

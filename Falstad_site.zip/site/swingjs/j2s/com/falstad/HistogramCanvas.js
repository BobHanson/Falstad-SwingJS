(function(){var P$=Clazz.newPackage("com.falstad"),I$=[[0,'java.awt.Dimension',['com.falstad.Gas','.Setup1Equal'],['com.falstad.Gas','.Setup1Extreme'],['com.falstad.Gas','.Setup1Single'],['com.falstad.Gas','.Setup1Small'],['com.falstad.Gas','.Setup2Random'],['com.falstad.Gas','.Setup2Equal'],['com.falstad.Gas','.Setup3Random'],['com.falstad.Gas','.Setup3Equal'],['com.falstad.Gas','.SetupBrownian'],['com.falstad.Gas','.SetupExpansion'],'java.util.Vector',['com.falstad.Gas','.Setup1Random'],'java.text.NumberFormat','java.awt.Color','com.falstad.GasLayout','com.falstad.GasCanvas','com.falstad.HistogramCanvas','a2s.Choice','a2s.Checkbox','a2s.Button','a2s.Label','a2s.Scrollbar','java.util.Random',['com.falstad.Gas','.Molecule']]],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "HistogramCanvas", null, 'a2s.Canvas');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['pg','com.falstad.Gas']]]

Clazz.newMeth(C$, 'c$$com_falstad_Gas',  function (p) {
Clazz.super_(C$, this);
this.pg=p;
}, 1);

Clazz.newMeth(C$, 'getPreferredSize$',  function () {
return Clazz.new_($I$(1,1).c$$I$I,[125, 50]);
});

Clazz.newMeth(C$, 'update$java_awt_Graphics',  function (g) {
this.pg.updateHistogram$java_awt_Graphics(g);
});

Clazz.newMeth(C$, 'paintComponent$java_awt_Graphics',  function (g) {
this.pg.updateHistogram$java_awt_Graphics(g);
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v2');//Created 2024-02-12 21:09:28 Java2ScriptVisitor version 5.0.1-v2 net.sf.j2s.core.jar version 5.0.1-v2

(function(){var P$=Clazz.newPackage("com.falstad"),I$=[['java.awt.Dimension','com.falstad.VecDemoFrame',['com.falstad.VecDemoFrame','.InverseRadialDouble'],['com.falstad.VecDemoFrame','.InverseRadialDipole'],['com.falstad.VecDemoFrame','.InverseSquaredRadial'],['com.falstad.VecDemoFrame','.InverseRadialQuad'],['com.falstad.VecDemoFrame','.InverseSquaredRadialDouble'],['com.falstad.VecDemoFrame','.InverseSquaredRadialDipole'],['com.falstad.VecDemoFrame','.InverseRotational'],['com.falstad.VecDemoFrame','.InverseSquaredRadialQuad'],['com.falstad.VecDemoFrame','.ConductingPlate'],'com.falstad.Complex',['com.falstad.VecDemoFrame','.ChargedPlate'],['com.falstad.VecDemoFrame','.ChargedPlatePair'],['com.falstad.VecDemoFrame','.ChargedPlateDipole'],['com.falstad.VecDemoFrame','.InfiniteChargedPlane'],['com.falstad.VecDemoFrame','.Cylinder'],['com.falstad.VecDemoFrame','.CylinderAndLineCharge'],['com.falstad.VecDemoFrame','.CylinderInField'],['com.falstad.VecDemoFrame','.DielectricCylinderInFieldE'],['com.falstad.VecDemoFrame','.SlottedPlane'],['com.falstad.VecDemoFrame','.PlanePair'],['com.falstad.VecDemoFrame','.InverseRotationalPotential'],['com.falstad.VecDemoFrame','.InverseRotationalDouble'],['com.falstad.VecDemoFrame','.InverseRotationalDoubleExt'],['com.falstad.VecDemoFrame','.InverseRotationalDipole'],['com.falstad.VecDemoFrame','.InverseRotationalDipoleExt'],['com.falstad.VecDemoFrame','.OneDirectionFunction'],['com.falstad.VecDemoFrame','.MovingChargeField'],['com.falstad.VecDemoFrame','.InverseSquaredRadialSphere'],['com.falstad.VecDemoFrame','.ConstRadial'],['com.falstad.VecDemoFrame','.LinearRadial'],['com.falstad.VecDemoFrame','.ConstantToYAxis'],['com.falstad.VecDemoFrame','.LinearToYAxis'],['com.falstad.VecDemoFrame','.LinearToXYAxes'],['com.falstad.VecDemoFrame','.InverseToYAxis'],['com.falstad.VecDemoFrame','.InverseSquareRotational'],['com.falstad.VecDemoFrame','.LinearRotational'],['com.falstad.VecDemoFrame','.ConstantRotational'],['com.falstad.VecDemoFrame','.FxEqualsYField'],['com.falstad.VecDemoFrame','.FxEqualsY2'],['com.falstad.VecDemoFrame','.Saddle'],['com.falstad.VecDemoFrame','.RotationalExpansion'],['com.falstad.VecDemoFrame','.Function4Field'],['com.falstad.VecDemoFrame','.Function5Field'],['com.falstad.VecDemoFrame','.Function6Field'],['com.falstad.VecDemoFrame','.Function7Field'],['com.falstad.VecDemoFrame','.PendulumPotential'],['com.falstad.VecDemoFrame','.Function8Field'],['com.falstad.VecDemoFrame','.UserDefinedPotential'],['com.falstad.VecDemoFrame','.ExprParser'],['com.falstad.VecDemoFrame','.UserDefinedFunction'],['com.falstad.VecDemoFrame','.Expr'],'java.awt.Color','java.util.Vector',['com.falstad.VecDemoFrame','.InverseRadial'],'java.util.Random',['com.falstad.VecDemoFrame','.Particle'],'com.falstad.VecDemoLayout','com.falstad.VecDemoCanvas','a2s.Choice','a2s.Checkbox','a2s.Button','a2s.Label','com.falstad.DecentScrollbar',['com.falstad.VecDemoFrame','.AuxBar'],'a2s.TextField','java.awt.Rectangle','java.awt.image.MemoryImageSource',['com.falstad.VecDemoFrame','.GridElement'],['com.falstad.VecDemoFrame','.FloatPair'],['com.falstad.VecDemoFrame','.DrawData'],'java.text.NumberFormat','java.net.URL']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "VecDemo", null, 'a2s.Applet', 'java.awt.event.ComponentListener');
C$.ogf = null;

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.started = false;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.started = false;
}, 1);

Clazz.newMeth(C$, 'destroyFrame', function () {
if (C$.ogf != null ) C$.ogf.dispose();
C$.ogf = null;
this.repaint();
});

Clazz.newMeth(C$, 'init', function () {
this.addComponentListener$java_awt_event_ComponentListener(this);
});

Clazz.newMeth(C$, 'main', function (args) {
var demo = Clazz.new_(C$);
demo.showFrame();
}, 1);

Clazz.newMeth(C$, 'showFrame', function () {
if (C$.ogf == null ) {
this.started = true;
C$.ogf = Clazz.new_((I$[2]||$incl$(2)).c$$com_falstad_VecDemo,[this]);
C$.ogf.initFrame();
this.repaint();
}});

Clazz.newMeth(C$, ['paint$java_awt_Graphics','paint'], function (g) {
C$.superclazz.prototype.paint$java_awt_Graphics.apply(this, [g]);
var s = "Applet is open in a separate window.";
if (!this.started) s = "Applet is starting.";
 else if (C$.ogf == null ) s = "Applet is finished.";
 else if (C$.ogf.useFrame) C$.ogf.triggerShow();
if (C$.ogf == null  || C$.ogf.useFrame ) g.drawString$S$I$I(s, 10, 30);
});

Clazz.newMeth(C$, ['componentHidden$java_awt_event_ComponentEvent','componentHidden'], function (e) {
});

Clazz.newMeth(C$, ['componentMoved$java_awt_event_ComponentEvent','componentMoved'], function (e) {
});

Clazz.newMeth(C$, ['componentShown$java_awt_event_ComponentEvent','componentShown'], function (e) {
this.showFrame();
});

Clazz.newMeth(C$, ['componentResized$java_awt_event_ComponentEvent','componentResized'], function (e) {
});

Clazz.newMeth(C$, 'destroy', function () {
if (C$.ogf != null ) C$.ogf.dispose();
C$.ogf = null;
this.repaint();
});

Clazz.newMeth(C$);
})();
//Created 2018-03-18 11:47:31

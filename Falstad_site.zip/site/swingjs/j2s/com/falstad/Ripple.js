(function(){var P$=Clazz.newPackage("com.falstad"),I$=[['java.awt.Dimension','com.falstad.RippleFrame',['com.falstad.RippleFrame','.ImportDialogLayout'],'a2s.TextArea','a2s.Button','java.awt.Point',['com.falstad.RippleFrame','.DoubleSourceSetup'],['com.falstad.RippleFrame','.QuadrupleSourceSetup'],['com.falstad.RippleFrame','.SingleSlitSetup'],['com.falstad.RippleFrame','.DoubleSlitSetup'],['com.falstad.RippleFrame','.TripleSlitSetup'],['com.falstad.RippleFrame','.ObstacleSetup'],['com.falstad.RippleFrame','.HalfPlaneSetup'],['com.falstad.RippleFrame','.DipoleSourceSetup'],['com.falstad.RippleFrame','.LateralQuadrupoleSetup'],['com.falstad.RippleFrame','.LinearQuadrupoleSetup'],['com.falstad.RippleFrame','.HexapoleSetup'],['com.falstad.RippleFrame','.OctupoleSetup'],['com.falstad.RippleFrame','.Multi12Setup'],['com.falstad.RippleFrame','.PlaneWaveSetup'],['com.falstad.RippleFrame','.IntersectingPlaneWavesSetup'],['com.falstad.RippleFrame','.PhasedArray1Setup'],['com.falstad.RippleFrame','.PhasedArray2Setup'],['com.falstad.RippleFrame','.PhasedArray3Setup'],['com.falstad.RippleFrame','.DopplerSetup'],['com.falstad.RippleFrame','.Doppler2Setup'],['com.falstad.RippleFrame','.SonicBoomSetup'],['com.falstad.RippleFrame','.BigModeSetup'],['com.falstad.RippleFrame','.OneByOneModesSetup'],['com.falstad.RippleFrame','.OneByNModesSetup'],['com.falstad.RippleFrame','.NByNModesSetup'],['com.falstad.RippleFrame','.OneByNModeCombosSetup'],['com.falstad.RippleFrame','.NByNModeCombosSetup'],['com.falstad.RippleFrame','.ZeroByOneModesSetup'],['com.falstad.RippleFrame','.ZeroByNModesSetup'],['com.falstad.RippleFrame','.NByNAcoModesSetup'],['com.falstad.RippleFrame','.CoupledCavitiesSetup'],['com.falstad.RippleFrame','.BeatsSetup'],['com.falstad.RippleFrame','.SlowMediumSetup'],['com.falstad.RippleFrame','.RefractionSetup'],['com.falstad.RippleFrame','.InternalReflectionSetup'],['com.falstad.RippleFrame','.CoatingSetup'],['com.falstad.RippleFrame','.ZonePlateEvenSetup'],['com.falstad.RippleFrame','.ZonePlateOddSetup'],['com.falstad.RippleFrame','.CircleSetup'],['com.falstad.RippleFrame','.EllipseSetup'],['com.falstad.RippleFrame','.ResonantCavitiesSetup'],['com.falstad.RippleFrame','.ResonantCavities2Setup'],['com.falstad.RippleFrame','.RoomResonanceSetup'],['com.falstad.RippleFrame','.Waveguides1Setup'],['com.falstad.RippleFrame','.Waveguides2Setup'],['com.falstad.RippleFrame','.Waveguides3Setup'],['com.falstad.RippleFrame','.Waveguides4Setup'],['com.falstad.RippleFrame','.Waveguides5Setup'],['com.falstad.RippleFrame','.ParabolicMirror1Setup'],['com.falstad.RippleFrame','.ParabolicMirror2Setup'],['com.falstad.RippleFrame','.SoundDuctSetup'],['com.falstad.RippleFrame','.BaffledPistonSetup'],['com.falstad.RippleFrame','.LowPassFilter1Setup'],['com.falstad.RippleFrame','.LowPassFilter2Setup'],['com.falstad.RippleFrame','.HighPassFilter1Setup'],['com.falstad.RippleFrame','.HighPassFilter2Setup'],['com.falstad.RippleFrame','.BandStopFilter1Setup'],['com.falstad.RippleFrame','.BandStopFilter2Setup'],['com.falstad.RippleFrame','.BandStopFilter3Setup'],['com.falstad.RippleFrame','.PlanarConvexLensSetup'],['com.falstad.RippleFrame','.BiconvexLensSetup'],['com.falstad.RippleFrame','.PlanarConcaveSetup'],['com.falstad.RippleFrame','.CircularPrismSetup'],['com.falstad.RippleFrame','.RightAnglePrismSetup'],['com.falstad.RippleFrame','.PorroPrismSetup'],['com.falstad.RippleFrame','.ScatteringSetup'],['com.falstad.RippleFrame','.LloydsMirrorSetup'],['com.falstad.RippleFrame','.TempGradient1'],['com.falstad.RippleFrame','.TempGradient2'],['com.falstad.RippleFrame','.TempGradient3'],['com.falstad.RippleFrame','.TempGradient4'],['com.falstad.RippleFrame','.DispersionSetup'],'java.util.Vector',['com.falstad.RippleFrame','.SingleSourceSetup'],['com.falstad.RippleFrame','.OscSource'],'com.falstad.RippleLayout','com.falstad.RippleCanvas','a2s.Choice','a2s.Checkbox','a2s.Label','a2s.Scrollbar','java.awt.Color','java.util.Random','java.awt.image.MemoryImageSource','java.util.StringTokenizer',['com.falstad.RippleFrame','.ImportDialog']]],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "Ripple", null, 'a2s.Applet', 'java.awt.event.ComponentListener');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.ogf = null;
this.started = false;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.started = false;
}, 1);

Clazz.newMeth(C$, 'destroyFrame', function () {
if (this.ogf != null ) this.ogf.dispose();
this.ogf = null;
this.repaint();
});

Clazz.newMeth(C$, 'init', function () {
this.addComponentListener$java_awt_event_ComponentListener(this);
});

Clazz.newMeth(C$, 'main', function (args) {
var ripple = Clazz.new_(C$);
ripple.showFrame();
}, 1);

Clazz.newMeth(C$, 'showFrame', function () {
if (this.ogf == null ) {
this.started = true;
this.ogf = Clazz.new_((I$[2]||$incl$(2)).c$$com_falstad_Ripple,[this]);
this.ogf.initFrame();
this.repaint();
}});

Clazz.newMeth(C$, ['paint$java_awt_Graphics','paint'], function (g) {
C$.superclazz.prototype.paint$java_awt_Graphics.apply(this, [g]);
var s = "Applet is open in a separate window.";
if (!this.started) s = "Applet is starting.";
 else if (this.ogf == null ) s = "Applet is finished.";
 else if (this.ogf.useFrame) this.ogf.triggerShow();
if (this.ogf == null  || this.ogf.useFrame ) g.drawString$S$I$I(s, 10, 30);
});

Clazz.newMeth(C$, ['componentHidden$java_awt_event_ComponentEvent','componentHidden'], function (e) {
});

Clazz.newMeth(C$, ['componentMoved$java_awt_event_ComponentEvent','componentMoved'], function (e) {
});

Clazz.newMeth(C$, ['componentShown$java_awt_event_ComponentEvent','componentShown'], function (e) {
this.showFrame();
});

Clazz.newMeth(C$, ['componentResized$java_awt_event_ComponentEvent','componentResized'], function (e) {
if (this.ogf != null ) this.ogf.handleResize();
});

Clazz.newMeth(C$, 'destroy', function () {
if (this.ogf != null ) this.ogf.dispose();
this.ogf = null;
this.repaint();
});

Clazz.newMeth(C$);
})();
//Created 2018-03-18 11:47:28

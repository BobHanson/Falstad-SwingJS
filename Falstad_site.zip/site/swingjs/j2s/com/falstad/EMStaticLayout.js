(function(){var P$=Clazz.newPackage("com.falstad"),I$=[['java.awt.Dimension','com.falstad.EMStaticFrame',['com.falstad.EMStaticFrame','.DoubleChargeSetup'],['com.falstad.EMStaticFrame','.DipoleChargeSetup'],['com.falstad.EMStaticFrame','.ChargePlaneSetup'],['com.falstad.EMStaticFrame','.DipoleUniformSetup'],['com.falstad.EMStaticFrame','.QuadChargeSetup'],['com.falstad.EMStaticFrame','.ConductingPlanesSetup'],['com.falstad.EMStaticFrame','.ChargedPlanesSetup'],['com.falstad.EMStaticFrame','.ConductingCylinderSetup'],['com.falstad.EMStaticFrame','.GroundedCylinderSetup'],['com.falstad.EMStaticFrame','.GroundedCylinderUniformSetup'],['com.falstad.EMStaticFrame','.ChargedCylinderSetup'],['com.falstad.EMStaticFrame','.ChargedHollowCylinder1Setup'],['com.falstad.EMStaticFrame','.ChargedHollowCylinder2Setup'],['com.falstad.EMStaticFrame','.FloatingCylinderSetup'],['com.falstad.EMStaticFrame','.FloatingCylinder2Setup'],['com.falstad.EMStaticFrame','.ConductingBoxSetup'],['com.falstad.EMStaticFrame','.HollowFloatingCylinderSetup'],['com.falstad.EMStaticFrame','.HollowFloatingCylinder2Setup'],['com.falstad.EMStaticFrame','.SharpPointSetup'],['com.falstad.EMStaticFrame','.CornerSetup'],['com.falstad.EMStaticFrame','.Angle45Setup'],['com.falstad.EMStaticFrame','.Angle135Setup'],['com.falstad.EMStaticFrame','.DielectricCylinderSetup'],['com.falstad.EMStaticFrame','.DielectricCylinderFieldSetup'],['com.falstad.EMStaticFrame','.Dielectric1Setup'],['com.falstad.EMStaticFrame','.Dielectric2Setup'],['com.falstad.EMStaticFrame','.DielectricDipoleSetup'],['com.falstad.EMStaticFrame','.DielecCapSetup'],['com.falstad.EMStaticFrame','.ConductingPlanesGapSetup'],['com.falstad.EMStaticFrame','.SlottedConductingPlaneSetup'],['com.falstad.EMStaticFrame','.Shielding1Setup'],['com.falstad.EMStaticFrame','.Shielding2Setup'],['com.falstad.EMStaticFrame','.BoxOneSideSetup'],['com.falstad.EMStaticFrame','.QuadrupoleLensSetup'],['com.falstad.EMStaticFrame','.ConductingWireSetup'],['com.falstad.EMStaticFrame','.ResistorSetup'],['com.falstad.EMStaticFrame','.ResistorsParallelSetup'],['com.falstad.EMStaticFrame','.Current2D1Setup'],['com.falstad.EMStaticFrame','.Current2D2Setup'],'java.util.Vector',['com.falstad.EMStaticFrame','.SingleChargeSetup'],['com.falstad.EMStaticFrame','.Charge'],'com.falstad.EMStaticLayout','com.falstad.EMStaticCanvas','a2s.Choice','a2s.Button','a2s.Checkbox','a2s.Label','a2s.Scrollbar','java.awt.Color',['com.falstad.EMStaticFrame','.GridElement'],['com.falstad.EMStaticFrame','.SolverGrid'],'java.text.NumberFormat',['com.falstad.EMStaticFrame','.SolverElement'],'java.awt.Point']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "EMStaticLayout", null, null, 'java.awt.LayoutManager');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'addLayoutComponent$S$java_awt_Component', function (name, c) {
});

Clazz.newMeth(C$, 'removeLayoutComponent$java_awt_Component', function (c) {
});

Clazz.newMeth(C$, 'preferredLayoutSize$java_awt_Container', function (target) {
return Clazz.new_((I$[1]||$incl$(1)).c$$I$I,[500, 500]);
});

Clazz.newMeth(C$, 'minimumLayoutSize$java_awt_Container', function (target) {
return Clazz.new_((I$[1]||$incl$(1)).c$$I$I,[100, 100]);
});

Clazz.newMeth(C$, 'layoutContainer$java_awt_Container', function (target) {
var insets = target.insets();
var targetw = target.size().width - insets.left - insets.right ;
var cw = (targetw * 2/3|0);
var targeth = target.size().height - (insets.top + insets.bottom);
target.getComponent$I(0).setLocation$I$I(insets.left, insets.top);
target.getComponent$I(0).resize$I$I(cw, targeth);
var barwidth = targetw - cw;
cw = cw+(insets.left);
var i;
var h = insets.top;
for (i = 1; i < target.getComponentCount(); i++) {
var m = target.getComponent$I(i);
if (m.isVisible()) {
var d = m.getPreferredSize();
if (Clazz.instanceOf(m, "a2s.Scrollbar")) d.width = barwidth;
if (Clazz.instanceOf(m, "a2s.Label")) {
h = h+((d.height/5|0));
d.width = barwidth;
}m.setLocation$I$I(cw, h);
m.resize$I$I(d.width, d.height);
h = h+(d.height);
}}
});
})();
//Created 2018-03-18 11:47:19

(function(){var P$=Clazz.newPackage("com.falstad"),I$=[[0,'java.awt.Dimension','com.falstad.EulerFrame','com.falstad.EulerLayout','com.falstad.EulerCanvas','a2s.Checkbox','a2s.Choice','a2s.Label','a2s.Scrollbar','java.awt.Color','java.text.NumberFormat']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "Euler", null, 'a2s.Applet', 'java.awt.event.ComponentListener');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.started=false;
},1);

C$.$fields$=[['Z',['started'],'O',['ogf','com.falstad.EulerFrame']]]

Clazz.newMeth(C$, 'destroyFrame$',  function () {
if (this.ogf != null ) this.ogf.dispose$();
this.ogf=null;
this.repaint$();
});

Clazz.newMeth(C$, ['init$','init'],  function () {
this.addComponentListener$java_awt_event_ComponentListener(this);
});

Clazz.newMeth(C$, 'showFrame$',  function () {
if (this.ogf == null ) {
this.started=true;
this.ogf=Clazz.new_($I$(2,1).c$$com_falstad_Euler,[this]);
this.ogf.init$();
this.repaint$();
}});

Clazz.newMeth(C$, ['paint$java_awt_Graphics','paint'],  function (g) {
C$.superclazz.prototype.paint$java_awt_Graphics.apply(this, [g]);
var s="Applet is open in a separate window.";
if (!this.started) s="Applet is starting.";
 else if (this.ogf == null ) s="Applet is finished.";
 else if (this.ogf.useFrame) this.ogf.triggerShow$();
if (this.ogf == null  || this.ogf.useFrame ) g.drawString$S$I$I(s, 10, 30);
});

Clazz.newMeth(C$, ['componentHidden$java_awt_event_ComponentEvent','componentHidden'],  function (e) {
});

Clazz.newMeth(C$, ['componentMoved$java_awt_event_ComponentEvent','componentMoved'],  function (e) {
});

Clazz.newMeth(C$, ['componentShown$java_awt_event_ComponentEvent','componentShown'],  function (e) {
this.showFrame$();
});

Clazz.newMeth(C$, ['componentResized$java_awt_event_ComponentEvent','componentResized'],  function (e) {
});

Clazz.newMeth(C$, ['destroy$','destroy'],  function () {
if (this.ogf != null ) this.ogf.dispose$();
this.ogf=null;
this.repaint$();
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v2');//Created 2024-02-12 21:09:28 Java2ScriptVisitor version 5.0.1-v2 net.sf.j2s.core.jar version 5.0.1-v2

(function(){var P$=Clazz.newPackage("com.falstad"),I$=[['java.awt.Dimension','com.falstad.Wave2dFrame',['com.falstad.Wave2dFrame','.DoubleSlitSetup'],['com.falstad.Wave2dFrame','.GratingSetup'],['com.falstad.Wave2dFrame','.ObstacleSetup'],['com.falstad.Wave2dFrame','.ZonePlateEvenSetup'],['com.falstad.Wave2dFrame','.ZonePlateOddSetup'],['com.falstad.Wave2dFrame','.ZonePlatePhaseSetup'],['com.falstad.Wave2dFrame','.ZonePlateBlazedSetup'],['com.falstad.Wave2dFrame','.Hologram1Setup'],['com.falstad.Wave2dFrame','.Hologram2Setup'],'java.util.Vector',['com.falstad.Wave2dFrame','.SingleSlitSetup'],'com.falstad.Wave2dLayout','com.falstad.Wave2dCanvas','a2s.Choice','a2s.Checkbox','a2s.Button','a2s.Label','a2s.Scrollbar','java.util.Random','java.awt.Color','java.awt.image.MemoryImageSource','com.falstad.FFT','java.text.NumberFormat']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "Wave2dCanvas", null, 'a2s.Canvas');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.pg = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$com_falstad_Wave2dFrame', function (p) {
Clazz.super_(C$, this,1);
this.pg = p;
}, 1);

Clazz.newMeth(C$, 'getPreferredSize', function () {
return Clazz.new_((I$[1]||$incl$(1)).c$$I$I,[300, 400]);
});

Clazz.newMeth(C$, 'update$java_awt_Graphics', function (g) {
this.pg.updateWave2d$java_awt_Graphics(g);
});

Clazz.newMeth(C$, 'paint$java_awt_Graphics', function (g) {
this.pg.updateWave2d$java_awt_Graphics(g);
});

Clazz.newMeth(C$);
})();
//Created 2018-03-18 11:47:33

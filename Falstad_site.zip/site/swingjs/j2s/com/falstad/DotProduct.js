(function(){var P$=Clazz.newPackage("com.falstad"),I$=[[0,'java.awt.Color','java.awt.Dimension','com.falstad.DotProductLayout','com.falstad.DotProductCanvas','a2s.Button','java.util.Random','java.awt.Font','java.text.NumberFormat']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "DotProduct", null, 'a2s.Applet', ['java.awt.event.ComponentListener', 'java.awt.event.ActionListener', 'java.awt.event.AdjustmentListener', 'java.awt.event.MouseMotionListener', 'java.awt.event.MouseListener']);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.engine=null;
this.selection=-1;
},1);

C$.$fields$=[['I',['selection'],'O',['engine','Thread','winSize','java.awt.Dimension','dbimage','java.awt.Image','random','java.util.Random','swapButton','a2s.Button','vecs','double[][]','cv','com.falstad.DotProductCanvas']]]

Clazz.newMeth(C$, ['getAppletInfo$','getAppletInfo'],  function () {
return "DotProduct by Paul Falstad";
});

Clazz.newMeth(C$, 'getrand$I',  function (x) {
var q=this.random.nextInt$();
if (q < 0) q=-q;
return q % x;
});

Clazz.newMeth(C$, ['init$','init'],  function () {
this.setLayout$java_awt_LayoutManager(Clazz.new_($I$(3,1)));
this.cv=Clazz.new_($I$(4,1).c$$com_falstad_DotProduct,[this]);
this.cv.addComponentListener$java_awt_event_ComponentListener(this);
this.cv.addMouseMotionListener$java_awt_event_MouseMotionListener(this);
this.cv.addMouseListener$java_awt_event_MouseListener(this);
this.add$java_awt_Component(this.swapButton=Clazz.new_($I$(5,1).c$$S,["Swap"]));
this.swapButton.addActionListener$java_awt_event_ActionListener(this);
this.add$java_awt_Component(this.cv);
this.setBackground$java_awt_Color($I$(1).black);
this.setForeground$java_awt_Color($I$(1).lightGray);
this.random=Clazz.new_($I$(6,1));
this.vecs=Clazz.array(Double.TYPE, [2, 2]);
this.vecs[0][0]=0;
this.vecs[0][1]=1;
this.vecs[1][0]=1;
this.vecs[1][1]=1;
this.reinit$();
this.repaint$();
});

Clazz.newMeth(C$, 'reinit$',  function () {
var d=this.winSize=this.cv.getSize$();
if (this.winSize.width == 0) return;
this.dbimage=this.createImage$I$I(d.width, d.height);
});

Clazz.newMeth(C$, 'findVecCoords$D$D$IA',  function (x, y, result) {
var cy=(this.winSize.height/4|0);
var cx=cy;
result[0]=((cx * (x + 2))|0);
result[1]=((cy * (2 - y))|0);
});

Clazz.newMeth(C$, 'findVecCoords$I$IA',  function (num, result) {
this.findVecCoords$D$D$IA(this.vecs[num][0], this.vecs[num][1], result);
});

Clazz.newMeth(C$, 'drawArrow$java_awt_Graphics$I$I$I$I$D',  function (g, x1, y1, x2, y2, len) {
g.drawLine$I$I$I$I(x1, y1, x2, y2);
if (len > 0.05 ) {
var l=java.lang.Math.sqrt((x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1));
var hatx=(x2 - x1) / l;
var haty=(y2 - y1) / l;
var as=10;
g.drawLine$I$I$I$I(x2, y2, ((haty * as - hatx * as + x2)|0), ((-hatx * as - haty * as + y2)|0));
g.drawLine$I$I$I$I(x2, y2, ((-haty * as - hatx * as + x2)|0), ((hatx * as - haty * as + y2)|0));
}});

Clazz.newMeth(C$, 'drawBar$java_awt_Graphics$I$D',  function (g, offset, val) {
var x=((this.winSize.width * val / 6)|0);
var cx=(this.winSize.width/2|0);
var h=5;
var y=this.winSize.height + h * offset;
var y2=y + h - 1;
if (val < 0 ) g.fillRect$I$I$I$I(cx + x, y, -x, h);
 else g.fillRect$I$I$I$I(cx, y, x, h);
});

Clazz.newMeth(C$, ['updateDotProduct$java_awt_Graphics','updateDotProduct'],  function (realg) {
var alen=java.lang.Math.sqrt(this.vecs[0][0] * this.vecs[0][0] + this.vecs[0][1] * this.vecs[0][1]);
var blen=java.lang.Math.sqrt(this.vecs[1][0] * this.vecs[1][0] + this.vecs[1][1] * this.vecs[1][1]);
var piadj=57.29577957855229;
var dot=this.vecs[0][0] * this.vecs[1][0] + this.vecs[0][1] * this.vecs[1][1];
var acosth=(blen > 0 ) ? dot / blen : 0;
var costh=(alen > 0 ) ? acosth / alen : 0;
var theta=java.lang.Math.acos(costh) * piadj;
var g=this.dbimage.getGraphics$();
if (this.winSize == null  || this.winSize.width == 0 ) return;
g.setColor$java_awt_Color(this.cv.getBackground$());
g.fillRect$I$I$I$I(0, 0, this.winSize.width, this.winSize.height);
g.setColor$java_awt_Color($I$(1).gray);
g.setFont$java_awt_Font(Clazz.new_($I$(7,1).c$$S$I$I,["Helvetica", 0, 15]));
var i;
var j;
for (i=-2; i <= 2; i++) {
var x=(this.winSize.height * (i + 2)/4|0);
g.drawLine$I$I$I$I(x, 0, x, this.winSize.height);
g.drawLine$I$I$I$I(0, x, this.winSize.height, x);
}
var cy=(this.winSize.height/2|0);
var cx=cy;
var vc=Clazz.array(Integer.TYPE, [2]);
if (blen > 0 ) {
var vc2=Clazz.array(Integer.TYPE, [2]);
this.findVecCoords$D$D$IA(this.vecs[1][0] * acosth / blen, this.vecs[1][1] * acosth / blen, vc);
this.findVecCoords$I$IA(0, vc2);
g.setColor$java_awt_Color($I$(1).gray);
g.drawLine$I$I$I$I(vc[0], vc[1], vc2[0], vc2[1]);
}if (alen > 0.1  && blen > 0.1  ) {
var c1x=(cx/10|0);
var c1y=(cy/10|0);
var a1=((piadj * java.lang.Math.atan2(this.vecs[0][1], this.vecs[0][0]))|0);
var a2=((piadj * java.lang.Math.atan2(this.vecs[1][1], this.vecs[1][0]))|0);
if (a1 > a2 && a1 < a2 + 180 ) {
var a3=a1;
a1=a2;
a2=a3;
}if (a2 < a1) a2+=360;
g.setColor$java_awt_Color($I$(1).orange);
g.drawArc$I$I$I$I$I$I(cx - c1x, cy - c1y, c1x * 2, c1y * 2, a1, a2 - a1);
}this.findVecCoords$I$IA(0, vc);
g.setColor$java_awt_Color($I$(1).red);
this.drawArrow$java_awt_Graphics$I$I$I$I$D(g, cx, cy, vc[0], vc[1], alen);
this.findVecCoords$I$IA(1, vc);
g.setColor$java_awt_Color($I$(1).cyan);
this.drawArrow$java_awt_Graphics$I$I$I$I$D(g, cx, cy, vc[0], vc[1], blen);
var yl=g.getFontMetrics$().getHeight$();
var y=yl;
var nf=$I$(8).getInstance$();
nf.setMaximumFractionDigits$I(3);
g.setColor$java_awt_Color($I$(1).red);
this.displayString$java_awt_Graphics$S$I(g, "A = (" + nf.format$D(this.vecs[0][0]) + ", " + nf.format$D(this.vecs[0][1]) + ")" , y+=yl);
this.displayString$java_awt_Graphics$S$I(g, "|A| = " + nf.format$D(alen), y+=yl);
this.drawBar$java_awt_Graphics$I$D(g, -4, alen);
g.setColor$java_awt_Color($I$(1).cyan);
this.displayString$java_awt_Graphics$S$I(g, "B = (" + nf.format$D(this.vecs[1][0]) + ", " + nf.format$D(this.vecs[1][1]) + ")" , y+=yl);
this.displayString$java_awt_Graphics$S$I(g, "|B| = " + nf.format$D(blen), y+=yl);
this.drawBar$java_awt_Graphics$I$D(g, -3, blen);
g.setColor$java_awt_Color($I$(1).yellow);
this.displayString$java_awt_Graphics$S$I(g, "|A| cos theta = " + nf.format$D(acosth), y+=yl);
this.drawBar$java_awt_Graphics$I$D(g, -2, acosth);
if (blen > 0 ) {
this.findVecCoords$D$D$IA(this.vecs[1][0] * acosth / blen, this.vecs[1][1] * acosth / blen, vc);
g.setColor$java_awt_Color($I$(1).yellow);
g.drawLine$I$I$I$I(cx, cy, vc[0], vc[1]);
}g.setColor$java_awt_Color($I$(1).white);
this.displayString$java_awt_Graphics$S$I(g, "cos theta = " + nf.format$D(costh), y+=yl);
g.setColor$java_awt_Color($I$(1).orange);
this.displayString$java_awt_Graphics$S$I(g, "theta = " + nf.format$D(theta) + "\u00b0" , y+=yl);
g.setColor$java_awt_Color($I$(1).green);
this.displayString$java_awt_Graphics$S$I(g, "A dot B = " + nf.format$D(dot), y+=yl);
this.drawBar$java_awt_Graphics$I$D(g, -1, dot);
realg.drawImage$java_awt_Image$I$I$java_awt_image_ImageObserver(this.dbimage, 0, 0, this);
});

Clazz.newMeth(C$, 'displayString$java_awt_Graphics$S$I',  function (g, s, y) {
var lx=this.winSize.height;
var lw=this.winSize.width - lx;
var fm=g.getFontMetrics$();
g.drawString$S$I$I(s, lx + ((lw - fm.stringWidth$S(s))/2|0), y);
});

Clazz.newMeth(C$, 'edit$java_awt_event_MouseEvent',  function (e) {
if (this.selection == -1) return;
var x=e.getX$();
var y=e.getY$();
var cy=(this.winSize.height/4|0);
var cx=cy;
var xf=x / cx - 2;
var yf=2 - y / cy;
if (xf < -2 ) xf=-2;
if (yf < -2 ) yf=-2;
if (xf > 2 ) xf=2;
if (yf > 2 ) yf=2;
this.vecs[this.selection][0]=xf;
this.vecs[this.selection][1]=yf;
this.repaint$();
});

Clazz.newMeth(C$, ['componentHidden$java_awt_event_ComponentEvent','componentHidden'],  function (e) {
});

Clazz.newMeth(C$, ['componentMoved$java_awt_event_ComponentEvent','componentMoved'],  function (e) {
});

Clazz.newMeth(C$, ['componentShown$java_awt_event_ComponentEvent','componentShown'],  function (e) {
this.repaint$();
});

Clazz.newMeth(C$, ['componentResized$java_awt_event_ComponentEvent','componentResized'],  function (e) {
this.reinit$();
this.repaint$();
});

Clazz.newMeth(C$, ['actionPerformed$java_awt_event_ActionEvent','actionPerformed'],  function (e) {
if (e.getSource$() === this.swapButton ) {
var x;
for (x=0; x < 2; x++) {
var y=this.vecs[0][x];
this.vecs[0][x]=this.vecs[1][x];
this.vecs[1][x]=y;
}
this.repaint$();
}});

Clazz.newMeth(C$, ['adjustmentValueChanged$java_awt_event_AdjustmentEvent','adjustmentValueChanged'],  function (e) {
});

Clazz.newMeth(C$, ['mouseDragged$java_awt_event_MouseEvent','mouseDragged'],  function (e) {
this.edit$java_awt_event_MouseEvent(e);
});

Clazz.newMeth(C$, ['mouseMoved$java_awt_event_MouseEvent','mouseMoved'],  function (e) {
if ((e.getModifiers$() & 16) != 0) return;
this.edit$java_awt_event_MouseEvent(e);
});

Clazz.newMeth(C$, ['mouseClicked$java_awt_event_MouseEvent','mouseClicked'],  function (e) {
});

Clazz.newMeth(C$, ['mouseEntered$java_awt_event_MouseEvent','mouseEntered'],  function (e) {
});

Clazz.newMeth(C$, ['mouseExited$java_awt_event_MouseEvent','mouseExited'],  function (e) {
});

Clazz.newMeth(C$, ['mousePressed$java_awt_event_MouseEvent','mousePressed'],  function (e) {
if ((e.getModifiers$() & 16) == 0) return;
var x=e.getX$();
var y=e.getY$();
var vc=Clazz.array(Integer.TYPE, [2]);
var i;
this.selection=-1;
var best=900;
for (i=0; i != 2; i++) {
this.findVecCoords$I$IA(i, vc);
var dx=x - vc[0];
var dy=y - vc[1];
var dist=dx * dx + dy * dy;
if (dist < best ) {
best=dist;
this.selection=i;
}}
if (this.selection != -1) this.edit$java_awt_event_MouseEvent(e);
});

Clazz.newMeth(C$, ['mouseReleased$java_awt_event_MouseEvent','mouseReleased'],  function (e) {
if ((e.getModifiers$() & 16) == 0) return;
this.selection=-1;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v2');//Created 2024-02-12 21:09:27 Java2ScriptVisitor version 5.0.1-v2 net.sf.j2s.core.jar version 5.0.1-v2

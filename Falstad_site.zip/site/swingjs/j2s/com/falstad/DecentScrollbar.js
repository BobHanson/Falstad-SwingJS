(function(){var P$=Clazz.newPackage("com.falstad"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "DecentScrollbar", null, 'a2s.Scrollbar', 'java.awt.event.AdjustmentListener');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['value','lo','hi'],'O',['$listener','com.falstad.DecentScrollbarListener']]]

Clazz.newMeth(C$, 'c$$com_falstad_DecentScrollbarListener$I$I$I',  function (parent, start, lo_, hi_) {
;C$.superclazz.c$$I$I$I$I$I.apply(this,[0, start, 1, lo_, hi_]);C$.$init$.apply(this);
this.value=start;
this.lo=lo_;
this.hi=hi_;
this.$listener=parent;
this.addAdjustmentListener$java_awt_event_AdjustmentListener(this);
}, 1);

Clazz.newMeth(C$, 'adjustmentValueChanged$java_awt_event_AdjustmentEvent',  function (e) {
if (this.getValueIsAdjusting$()) this.$listener.scrollbarValueChanged$com_falstad_DecentScrollbar(this);
 else this.$listener.scrollbarFinished$com_falstad_DecentScrollbar(this);
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v2');//Created 2024-02-12 21:09:27 Java2ScriptVisitor version 5.0.1-v2 net.sf.j2s.core.jar version 5.0.1-v2

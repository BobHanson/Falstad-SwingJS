(function(){var P$=Clazz.newPackage("com.falstad"),I$=[[0,'java.awt.Dimension','com.falstad.QuantumOscFrame','com.falstad.QuantumOscLayout','com.falstad.QuantumOscCanvas','a2s.MenuBar','a2s.Menu','a2s.Choice','a2s.Button','a2s.Checkbox','a2s.Label','a2s.Scrollbar',['com.falstad.QuantumOscFrame','.PhaseColor'],'java.awt.Color','java.util.Random','a2s.MenuItem','a2s.CheckboxMenuItem','javax.swing.ButtonGroup','javax.swing.JRadioButtonMenuItem',['com.falstad.QuantumOscFrame','.View'],['com.falstad.QuantumOscFrame','.Phasor'],'java.awt.image.MemoryImageSource','com.falstad.Complex',['com.falstad.QuantumOscFrame','.BasisState'],['com.falstad.QuantumOscFrame','.DerivedState']]],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "QuantumOsc", null, 'a2s.Applet');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[[]
,['O',['mf','com.falstad.QuantumOscFrame']]]

Clazz.newMeth(C$, 'main$SA',  function (args) {
C$.mf=Clazz.new_($I$(2,1).c$$com_falstad_QuantumOsc,[null]);
C$.mf.init$();
}, 1);

Clazz.newMeth(C$, 'destroyFrame$',  function () {
if (C$.mf != null ) C$.mf.dispose$();
C$.mf=null;
});

Clazz.newMeth(C$, ['init$','init'],  function () {
C$.mf=Clazz.new_($I$(2,1).c$$com_falstad_QuantumOsc,[this]);
C$.mf.init$();
});

Clazz.newMeth(C$, ['destroy$','destroy'],  function () {
if (C$.mf != null ) C$.mf.dispose$();
C$.mf=null;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v2');//Created 2024-02-12 21:09:28 Java2ScriptVisitor version 5.0.1-v2 net.sf.j2s.core.jar version 5.0.1-v2

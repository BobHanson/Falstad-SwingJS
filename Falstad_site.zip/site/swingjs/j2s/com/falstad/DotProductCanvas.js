(function(){var P$=Clazz.newPackage("com.falstad"),I$=[[0,'java.awt.Color','java.awt.Dimension','com.falstad.DotProductLayout','com.falstad.DotProductCanvas','a2s.Button','java.util.Random','java.awt.Font','java.text.NumberFormat']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "DotProductCanvas", null, 'a2s.Canvas');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['pg','com.falstad.DotProduct']]]

Clazz.newMeth(C$, 'c$$com_falstad_DotProduct',  function (p) {
Clazz.super_(C$, this);
this.pg=p;
this.setBackground$java_awt_Color($I$(1).BLACK);
}, 1);

Clazz.newMeth(C$, 'getPreferredSize$',  function () {
return Clazz.new_($I$(2,1).c$$I$I,[300, 400]);
});

Clazz.newMeth(C$, 'update$java_awt_Graphics',  function (g) {
this.pg.updateDotProduct$java_awt_Graphics(g);
});

Clazz.newMeth(C$, 'paintComponent$java_awt_Graphics',  function (g) {
C$.superclazz.prototype.paintComponent$java_awt_Graphics.apply(this, [g]);
this.pg.updateDotProduct$java_awt_Graphics(g);
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v2');//Created 2024-02-12 21:09:27 Java2ScriptVisitor version 5.0.1-v2 net.sf.j2s.core.jar version 5.0.1-v2

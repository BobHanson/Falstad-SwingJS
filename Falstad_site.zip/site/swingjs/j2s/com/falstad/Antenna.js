(function(){var P$=Clazz.newPackage("com.falstad"),I$=[[0,'java.awt.Dimension','com.falstad.AntennaFrame',['com.falstad.AntennaFrame','.LinearCenterSetup'],['com.falstad.AntennaFrame','.LoopSetup'],['com.falstad.AntennaFrame','.BroadsideArraySetup'],['com.falstad.AntennaFrame','.EndFireArraySetup'],['com.falstad.AntennaFrame','.BinomialArraySetup'],['com.falstad.AntennaFrame','.SchelkunoffSetup'],['com.falstad.AntennaFrame','.FourierSectoralSetup'],['com.falstad.AntennaFrame','.FourierFunctionSetup'],'java.util.Vector',['com.falstad.AntennaFrame','.LinearSetup'],'com.falstad.AntennaLayout','com.falstad.AntennaCanvas','a2s.Choice','a2s.Checkbox','a2s.Label','a2s.Scrollbar','java.awt.Color','java.util.Random','java.awt.image.MemoryImageSource','java.awt.Rectangle','java.text.NumberFormat']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "Antenna", null, 'a2s.Applet');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.started=false;
},1);

C$.$fields$=[['Z',['started']]
,['O',['ogf','com.falstad.AntennaFrame']]]

Clazz.newMeth(C$, 'destroyFrame$',  function () {
if (C$.ogf != null ) C$.ogf.dispose$();
C$.ogf=null;
});

Clazz.newMeth(C$, ['init$','init'],  function () {
C$.ogf=Clazz.new_($I$(2,1).c$$com_falstad_Antenna,[this]);
C$.ogf.init$();
});

Clazz.newMeth(C$, ['destroy$','destroy'],  function () {
if (C$.ogf != null ) C$.ogf.dispose$();
C$.ogf=null;
});

Clazz.newMeth(C$, 'main$SA',  function (args) {
C$.ogf=Clazz.new_($I$(2,1).c$$com_falstad_Antenna,[null]);
C$.ogf.init$();
}, 1);

Clazz.newMeth(C$, ['paint$java_awt_Graphics','paint'],  function (g) {
C$.superclazz.prototype.paint$java_awt_Graphics.apply(this, [g]);
var s="Applet is open in a separate window.";
if (!this.started) s="Applet is starting.";
 else if (C$.ogf == null ) s="Applet is finished.";
 else if (C$.ogf.useFrame) C$.ogf.triggerShow$();
if (C$.ogf == null  || C$.ogf.useFrame ) g.drawString$S$I$I(s, 10, 30);
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v2');//Created 2024-02-12 21:09:26 Java2ScriptVisitor version 5.0.1-v2 net.sf.j2s.core.jar version 5.0.1-v2

(function(){var P$=Clazz.newPackage("com.falstad"),I$=[['java.awt.Dimension','com.falstad.QuantumStatesFrame',['com.falstad.QuantumStatesFrame','.FiniteWellSetup'],['com.falstad.QuantumStatesFrame','.HarmonicOscillatorSetup'],['com.falstad.QuantumStatesFrame','.FiniteWellPairSetup'],['com.falstad.QuantumStatesFrame','.FiniteWellPairCoupledSetup'],['com.falstad.QuantumStatesFrame','.AsymmetricWellSetup'],['com.falstad.QuantumStatesFrame','.InfiniteWellFieldSetup'],['com.falstad.QuantumStatesFrame','.WellPairCoupledFieldSetup'],['com.falstad.QuantumStatesFrame','.CoulombSetup'],['com.falstad.QuantumStatesFrame','.QuarticOscillatorSetup'],['com.falstad.QuantumStatesFrame','.FiniteWellArraySetup'],['com.falstad.QuantumStatesFrame','.HarmonicWellArraySetup'],['com.falstad.QuantumStatesFrame','.CoulombWellArraySetup'],['com.falstad.QuantumStatesFrame','.FiniteWellArrayFieldSetup'],['com.falstad.QuantumStatesFrame','.FiniteWellArrayImpureSetup'],['com.falstad.QuantumStatesFrame','.FiniteWellArrayDislocSetup'],['com.falstad.QuantumStatesFrame','.RandomWellArraySetup'],['com.falstad.QuantumStatesFrame','.FiniteWell2ArraySetup'],['com.falstad.QuantumStatesFrame','.FiniteWellCoupledArraySetup'],['com.falstad.QuantumStatesFrame','.DeltaArraySetup'],'java.util.Vector',['com.falstad.QuantumStatesFrame','.InfiniteWellSetup'],'com.falstad.QuantumStatesLayout','com.falstad.QuantumStatesCanvas','a2s.MenuBar','a2s.Menu','a2s.Choice','a2s.Button','a2s.Checkbox','a2s.Label','com.falstad.DecentScrollbar','java.awt.Color','java.util.Random','java.text.NumberFormat','a2s.MenuItem','a2s.CheckboxMenuItem','javax.swing.ButtonGroup','javax.swing.JRadioButtonMenuItem',['com.falstad.QuantumStatesFrame','.View'],'java.awt.Cursor',['com.falstad.QuantumStatesFrame','.FFT']]],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "QuantumStatesCanvas", null, 'a2s.Canvas');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.pg = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$com_falstad_QuantumStatesFrame', function (p) {
Clazz.super_(C$, this,1);
this.pg = p;
}, 1);

Clazz.newMeth(C$, 'getPreferredSize', function () {
return Clazz.new_((I$[1]||$incl$(1)).c$$I$I,[300, 400]);
});

Clazz.newMeth(C$, 'update$java_awt_Graphics', function (g) {
this.pg.updateQuantumStates$java_awt_Graphics(g);
});

Clazz.newMeth(C$, 'paintComponent$java_awt_Graphics', function (g) {
C$.superclazz.prototype.paintComponent$java_awt_Graphics.apply(this, [g]);
this.pg.updateQuantumStates$java_awt_Graphics(g);
});

Clazz.newMeth(C$);
})();
//Created 2018-03-18 11:47:27

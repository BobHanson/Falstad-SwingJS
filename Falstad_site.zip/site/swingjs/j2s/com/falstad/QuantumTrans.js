(function(){var P$=Clazz.newPackage("com.falstad"),I$=[[0,'java.awt.Dimension','com.falstad.QuantumTransFrame',['com.falstad.QuantumTransFrame','.FiniteWellPairCoupledSetup'],['com.falstad.QuantumTransFrame','.HarmonicOscillatorSetup'],'java.util.Vector',['com.falstad.QuantumTransFrame','.InfiniteWellSetup'],'com.falstad.QuantumTransLayout','com.falstad.QuantumTransCanvas','a2s.MenuBar','a2s.Menu','a2s.Choice','a2s.Button','a2s.Checkbox','a2s.Label','com.falstad.DecentScrollbar','java.awt.Color','java.util.Random','a2s.MenuItem','a2s.CheckboxMenuItem','javax.swing.ButtonGroup','javax.swing.JRadioButtonMenuItem',['com.falstad.QuantumTransFrame','.View'],'java.awt.Cursor',['com.falstad.QuantumTransFrame','.FFT']]],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "QuantumTrans", null, 'a2s.Applet', 'java.awt.event.ComponentListener');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.started=false;
},1);

C$.$fields$=[['Z',['started']]
,['O',['qf','com.falstad.QuantumTransFrame']]]

Clazz.newMeth(C$, 'destroyFrame$',  function () {
if (C$.qf != null ) C$.qf.dispose$();
C$.qf=null;
this.repaint$();
});

Clazz.newMeth(C$, ['init$','init'],  function () {
this.addComponentListener$java_awt_event_ComponentListener(this);
});

Clazz.newMeth(C$, 'main$SA',  function (args) {
C$.qf=Clazz.new_($I$(2,1).c$$com_falstad_QuantumTrans,[null]);
C$.qf.init$();
}, 1);

Clazz.newMeth(C$, 'showFrame$',  function () {
if (C$.qf == null ) {
this.started=true;
C$.qf=Clazz.new_($I$(2,1).c$$com_falstad_QuantumTrans,[this]);
C$.qf.init$();
this.repaint$();
}});

Clazz.newMeth(C$, ['paint$java_awt_Graphics','paint'],  function (g) {
var s="Applet is open in a separate window.";
if (!this.started) s="Applet is starting.";
 else if (C$.qf == null ) s="Applet is finished.";
 else C$.qf.show$();
g.drawString$S$I$I(s, 10, 30);
});

Clazz.newMeth(C$, ['componentHidden$java_awt_event_ComponentEvent','componentHidden'],  function (e) {
});

Clazz.newMeth(C$, ['componentMoved$java_awt_event_ComponentEvent','componentMoved'],  function (e) {
});

Clazz.newMeth(C$, ['componentShown$java_awt_event_ComponentEvent','componentShown'],  function (e) {
this.showFrame$();
});

Clazz.newMeth(C$, ['componentResized$java_awt_event_ComponentEvent','componentResized'],  function (e) {
});

Clazz.newMeth(C$, ['destroy$','destroy'],  function () {
if (C$.qf != null ) C$.qf.dispose$();
C$.qf=null;
this.repaint$();
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v2');//Created 2024-02-12 21:09:29 Java2ScriptVisitor version 5.0.1-v2 net.sf.j2s.core.jar version 5.0.1-v2

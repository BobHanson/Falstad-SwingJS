(function(){var P$=Clazz.newPackage("com.falstad"),I$=[];
var C$=Clazz.newInterface(P$, "DecentScrollbarListener");
})();
//Created 2018-03-18 11:47:17
